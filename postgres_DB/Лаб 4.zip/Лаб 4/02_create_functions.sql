-- ================================================================
-- ЗАДАНИЕ 4 — Вариант А: Пароль к сейфу
-- Шаг 2: Создание функций
-- ================================================================

-- ── C-расширение ────────────────────────────────────────────────
-- Сначала убедитесь что safe_password.dll скопирован в:
-- C:\Program Files\PostgreSQL\17\lib\safe_password.dll

CREATE OR REPLACE FUNCTION find_safe_password(input text)
RETURNS text
AS 'safe_password', 'find_safe_password'
LANGUAGE C STRICT;

SELECT 'C-функция find_safe_password создана' AS status;

-- ── PL/pgSQL версия (для сравнения скорости) ───────────────────
CREATE OR REPLACE FUNCTION find_safe_password_plpgsql(input text)
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    pos     INT  := 50;
    steps   INT;
    dir     CHAR(1);
    result  TEXT := '';
    i       INT  := 1;
    len     INT;
BEGIN
    IF input IS NULL OR input = '' THEN
        RETURN '';
    END IF;

    len := length(input);

    WHILE i + 2 <= len LOOP
        dir := substring(input, i, 1);

        IF dir IN ('L', 'R') THEN
            BEGIN
                steps := substring(input, i + 1, 2)::INT;
            EXCEPTION WHEN OTHERS THEN
                i := i + 1;
                CONTINUE;
            END;

            IF dir = 'L' THEN
                pos := ((pos - steps) % 100 + 100) % 100;
            ELSE
                pos := (pos + steps) % 100;
            END IF;

            IF pos = 0 THEN
                result := result || LPAD(steps::TEXT, 2, '0');
            END IF;
        END IF;

        i := i + 3;
    END LOOP;

    RETURN result;
END;
$$;

SELECT 'PL/pgSQL функция find_safe_password_plpgsql создана' AS status;
