-- ================================================================
-- ЗАДАНИЕ 4 — Вариант А: Пароль к сейфу
-- Шаг 1: Создание таблицы
-- ================================================================

DROP TABLE IF EXISTS safe_combinations;

CREATE TABLE safe_combinations (
    id              SERIAL PRIMARY KEY,
    combination     TEXT NOT NULL,
    password_c      TEXT,
    password_plpgsql TEXT
);

SELECT 'Таблица safe_combinations создана' AS status;
