-- ================================================================
-- ЗАДАНИЕ 4 — Вариант А: Пароль к сейфу
-- Шаг 4: Вычисление паролей (C vs PL/pgSQL) + замер времени
-- ================================================================

-- ── C-расширение ────────────────────────────────────────────────
DO $$
DECLARE
    t_start TIMESTAMPTZ;
    t_end   TIMESTAMPTZ;
BEGIN
    t_start := clock_timestamp();

    UPDATE safe_combinations
    SET password_c = find_safe_password(combination);

    t_end := clock_timestamp();
    RAISE NOTICE 'C-расширение: % мс',
        round(extract(epoch FROM (t_end - t_start)) * 1000);
END;
$$;

-- ── PL/pgSQL ────────────────────────────────────────────────────
DO $$
DECLARE
    t_start TIMESTAMPTZ;
    t_end   TIMESTAMPTZ;
BEGIN
    t_start := clock_timestamp();

    UPDATE safe_combinations
    SET password_plpgsql = find_safe_password_plpgsql(combination);

    t_end := clock_timestamp();
    RAISE NOTICE 'PL/pgSQL: % мс',
        round(extract(epoch FROM (t_end - t_start)) * 1000);
END;
$$;

-- Проверка корректности (результаты должны совпадать)
SELECT COUNT(*) AS mismatches
FROM safe_combinations
WHERE password_c IS DISTINCT FROM password_plpgsql;
