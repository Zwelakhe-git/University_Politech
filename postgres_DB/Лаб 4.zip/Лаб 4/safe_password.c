#include "postgres.h"
#include "fmgr.h"
#include "utils/builtins.h"
#include <string.h>
#include <ctype.h>

PG_MODULE_MAGIC;

PG_FUNCTION_INFO_V1(find_safe_password);

/*
 * find_safe_password(input text) RETURNS text
 *
 * Сейф с 100 лимбами (0–99). Начальная позиция — 50.
 * Вход: строка вида "L68R48L05..." (L = влево, R = вправо, 2 цифры = шаги).
 * Выход: конкатенация всех двузначных чисел шагов, при которых лимб встал на 0.
 */
Datum find_safe_password(PG_FUNCTION_ARGS)
{
    text   *input      = PG_GETARG_TEXT_PP(0);
    char   *str        = text_to_cstring(input);
    int     len        = strlen(str);
    char    result[1024] = {0};
    int     rpos       = 0;
    int     pos        = 50;
    int     i          = 0;

    while (i + 2 < len)
    {
        char dir = str[i];

        if (dir != 'L' && dir != 'R') { i++; continue; }

        if (!isdigit((unsigned char)str[i+1]) ||
            !isdigit((unsigned char)str[i+2])) { i++; continue; }

        int steps = (str[i+1] - '0') * 10 + (str[i+2] - '0');

        if (dir == 'L')
            pos = ((pos - steps) % 100 + 100) % 100;
        else
            pos = (pos + steps) % 100;

        if (pos == 0 && rpos + 2 < (int)sizeof(result))
        {
            result[rpos++] = '0' + (steps / 10);
            result[rpos++] = '0' + (steps % 10);
        }

        i += 3;
    }

    pfree(str);
    PG_RETURN_TEXT_P(cstring_to_text(result));
}
