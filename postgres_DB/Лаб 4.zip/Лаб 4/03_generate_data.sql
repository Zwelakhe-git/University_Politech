-- ================================================================
-- ЗАДАНИЕ 4 — Вариант А: Пароль к сейфу
-- Шаг 3: Генератор данных (1 000 000 строк)
-- ================================================================

-- Функция-генератор одной случайной комбинации
CREATE OR REPLACE FUNCTION generate_combination()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    result      TEXT := '';
    n_commands  INT;
    dir         TEXT;
    steps       INT;
    i           INT;
BEGIN
    -- 5–10 команд, каждая 3 символа → строка 15–30 символов
    n_commands := 5 + floor(random() * 6)::INT;

    FOR i IN 1..n_commands LOOP
        IF random() < 0.5 THEN dir := 'L'; ELSE dir := 'R'; END IF;
        steps := floor(random() * 100)::INT;
        result := result || dir || LPAD(steps::TEXT, 2, '0');
    END LOOP;

    RETURN result;
END;
$$;

-- Вставка батчами по 50 000
DO $$
DECLARE
    batch_size  INT := 50000;
    total       INT := 1000000;
    inserted    INT := 0;
BEGIN
    WHILE inserted < total LOOP
        INSERT INTO safe_combinations (combination)
        SELECT generate_combination()
        FROM generate_series(1, batch_size);

        inserted := inserted + batch_size;
        RAISE NOTICE 'Вставлено: %/%', inserted, total;
    END LOOP;
    RAISE NOTICE 'Генерация завершена: % строк', total;
END;
$$;

SELECT COUNT(*) AS total_rows FROM safe_combinations;
