-- ================================================================
-- ЗАДАНИЕ 4 — Вариант А: Пароль к сейфу
-- Шаг 6: Сравнение скорости C vs PL/pgSQL на выборке
-- ================================================================

-- Тестируем на 100 000 строк чтобы быстрее
CREATE TEMP TABLE test_sample AS
SELECT id, combination
FROM safe_combinations
ORDER BY id
LIMIT 100000;

-- ── C-расширение ────────────────────────────────────────────────
DO $$
DECLARE
    t_start TIMESTAMPTZ;
    t_end   TIMESTAMPTZ;
BEGIN
    t_start := clock_timestamp();
    PERFORM find_safe_password(combination) FROM test_sample;
    t_end := clock_timestamp();
    RAISE NOTICE 'C-расширение: 100000 строк за % мс',
        round(extract(epoch FROM (t_end - t_start)) * 1000);
END;
$$;

-- ── PL/pgSQL ────────────────────────────────────────────────────
DO $$
DECLARE
    t_start TIMESTAMPTZ;
    t_end   TIMESTAMPTZ;
BEGIN
    t_start := clock_timestamp();
    PERFORM find_safe_password_plpgsql(combination) FROM test_sample;
    t_end := clock_timestamp();
    RAISE NOTICE 'PL/pgSQL: 100000 строк за % мс',
        round(extract(epoch FROM (t_end - t_start)) * 1000);
END;
$$;

DROP TABLE test_sample;
