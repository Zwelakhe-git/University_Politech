-- ================================================================
-- ЗАДАНИЕ 4 — Вариант А: Пароль к сейфу
-- Шаг 5: Основные запросы
-- ================================================================

-- ── а) Самый длинный пароль и количество таких паролей ──────────
-- Длина пароля в "поворотах" = length / 2 (каждый поворот = 2 цифры)

WITH lengths AS (
    SELECT
        id,
        password_c,
        length(password_c) / 2 AS turns
    FROM safe_combinations
    WHERE password_c IS NOT NULL AND password_c <> ''
),
max_len AS (
    SELECT MAX(turns) AS max_turns FROM lengths
)
SELECT
    m.max_turns                         AS longest_password_length,
    COUNT(*)                            AS count_of_passwords_with_max_length,
    MIN(l.password_c)                   AS example_password
FROM lengths l
JOIN max_len m ON l.turns = m.max_turns
GROUP BY m.max_turns;

-- ── б) Минимальное расстояние между двумя подряд истинными паролями
-- "Расстояние" = разница в id между соседними строками с непустым паролем

WITH true_passwords AS (
    SELECT
        id,
        LAG(id) OVER (ORDER BY id) AS prev_id
    FROM safe_combinations
    WHERE password_c IS NOT NULL AND password_c <> ''
),
distances AS (
    SELECT id - prev_id AS dist
    FROM true_passwords
    WHERE prev_id IS NOT NULL
)
SELECT
    MIN(dist) AS min_distance_between_passwords
FROM distances;

-- ── Дополнительно: распределение длин паролей ───────────────────
SELECT
    length(password_c) / 2  AS password_turns,
    COUNT(*)                 AS frequency
FROM safe_combinations
WHERE password_c IS NOT NULL AND password_c <> ''
GROUP BY 1
ORDER BY 1;
