CREATE OR REPLACE FUNCTION find_safe_password_plpgsql(input text)
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    current_pos INT := 50;
    steps INT;
    direction CHAR(1);
    result TEXT := '';
    i INT := 1;
    len INT;
    cmd_direction TEXT;
    cmd_steps TEXT;
BEGIN
    -- Проверка на NULL или пустую строку
    IF input IS NULL OR input = '' THEN
        RETURN '';
    END IF;
    
    len := length(input);
    
    WHILE i <= len LOOP
        -- Пропускаем если недостаточно символов
        IF i + 2 > len THEN
            EXIT;
        END IF;
        
        -- Извлекаем направление и шаги
        cmd_direction := substring(input, i, 1);
        cmd_steps := substring(input, i + 1, 2);
        
        -- Проверяем корректность направления
        IF cmd_direction IN ('L', 'R') THEN
            -- Преобразуем шаги в число
            BEGIN
                steps := cmd_steps::INT;
            EXCEPTION WHEN OTHERS THEN
                i := i + 1;
                CONTINUE;
            END;
            
            -- Вычисляем новую позицию
            IF cmd_direction = 'L' THEN
                current_pos := (current_pos - steps) % 100;
            ELSE
                current_pos := (current_pos + steps) % 100;
            END IF;
            
            -- Приводим к диапазону 0-99 (PostgreSQL % может дать отрицательный результат)
            current_pos := current_pos % 100;
            IF current_pos < 0 THEN
                current_pos := current_pos + 100;
            END IF;
            
            -- Если пришли на 0, добавляем steps
            IF current_pos = 0 THEN
                result := result || LPAD(steps::TEXT, 2, '0');
            END IF;
        END IF;
        
        i := i + 3;
    END LOOP;
    
    RETURN result;
END;
$$;