-- Используя C-функцию
WITH true_passwords AS (
    SELECT 
        id,
        password_c,
        LAG(id) OVER (ORDER BY id) as prev_id
    FROM safe_combinations
    WHERE password_c != ''
),
distances AS (
    SELECT 
        id - prev_id as distance
    FROM true_passwords
    WHERE prev_id IS NOT NULL
)
SELECT 
    MIN(distance) as min_distance_between_passwords
FROM distances;