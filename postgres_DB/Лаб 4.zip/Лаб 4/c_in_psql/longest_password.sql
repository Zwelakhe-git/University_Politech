-- С использованием C-функции
WITH password_lengths AS (
    SELECT 
        password_c,
        LENGTH(password_c) / 2 as num_zeros  -- /2 потому что каждый 0 дает 2 цифры
    FROM safe_combinations
    WHERE password_c != ''
),
max_length AS (
    SELECT MAX(num_zeros) as max_len FROM password_lengths
)
SELECT 
    max_len as longest_password_length,
    COUNT(*) as count_of_passwords_with_max_length
FROM password_lengths, max_length
WHERE num_zeros = max_len
GROUP BY max_len;

