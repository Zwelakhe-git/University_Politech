### c extension result

```bash
ЗАМЕЧАНИЕ:  C extension time: 16206.551000 ms
DO

ЗАМЕЧАНИЕ:  PL/pgSQL time: 211037.076000 ms
DO
```



| longest_password_length | count_of_passwords_with_max_length | min_distance_between_passwords |
| :---------------------- | :--------------------------------- | :----------------------------- |
| 8                       | 2                                  | 1                              |
|                         |                                    |                                |


### second test results
ЗАМЕЧАНИЕ:  C-расширение: 100000 строк обработано за 895.396000 миллисекунд
ЗАМЕЧАНИЕ:  PL/pgSQL: 100000 строк обработано за 23926.972000 миллисекунд
DO

```shell
"Subquery Scan on max_length_c  (cost=9596.79..9667.16 rows=1 width=44) (actual time=35.381..35.384 rows=1 loops=1)"
"  Buffers: shared hit=7846"
"  CTE password_stats_c"
"    ->  HashAggregate  (cost=9479.53..9526.43 rows=3127 width=12) (actual time=35.344..35.363 rows=7 loops=1)"
"          Group Key: (length(safe_combinations_test.password_c) / 2)"
"          Batches: 1  Memory Usage: 121kB"
"          Buffers: shared hit=7846"
"          ->  Seq Scan on safe_combinations_test  (cost=0.00..9287.76 rows=38353 width=4) (actual time=1.334..28.786 rows=38444 loops=1)"
"                Filter: ((password_c IS NOT NULL) AND (password_c <> ''::text))"
"                Rows Removed by Filter: 61556"
"                Buffers: shared hit=7846"
"  ->  Aggregate  (cost=70.36..70.37 rows=1 width=4) (actual time=35.374..35.374 rows=1 loops=1)"
"        Buffers: shared hit=7846"
"        ->  CTE Scan on password_stats_c  (cost=0.00..62.54 rows=3127 width=4) (actual time=35.348..35.368 rows=7 loops=1)"
"              Buffers: shared hit=7846"
"  SubPlan 2"
"    ->  CTE Scan on password_stats_c password_stats_c_1  (cost=0.00..70.36 rows=16 width=8) (actual time=0.002..0.002 rows=1 loops=1)"
"          Filter: (password_length = max_length_c.max_len)"
"          Rows Removed by Filter: 6"
"Planning:"
"  Buffers: shared hit=15 read=2"
"Planning Time: 163.735 ms"
"Execution Time: 35.446 ms"
```

### plpgsql test
```shell
"Subquery Scan on max_length_plpgsql  (cost=9596.79..9667.16 rows=1 width=44) (actual time=38.292..38.295 rows=1 loops=1)"
"  Buffers: shared hit=7846"
"  CTE password_stats_plpgsql"
"    ->  HashAggregate  (cost=9479.53..9526.43 rows=3127 width=12) (actual time=38.257..38.275 rows=6 loops=1)"
"          Group Key: (length(safe_combinations_test.password_plpgsql) / 2)"
"          Batches: 1  Memory Usage: 121kB"
"          Buffers: shared hit=7846"
"          ->  Seq Scan on safe_combinations_test  (cost=0.00..9287.76 rows=38353 width=4) (actual time=2.554..31.692 rows=38444 loops=1)"
"                Filter: ((password_plpgsql IS NOT NULL) AND (password_plpgsql <> ''::text))"
"                Rows Removed by Filter: 61556"
"                Buffers: shared hit=7846"
"  ->  Aggregate  (cost=70.36..70.37 rows=1 width=4) (actual time=38.285..38.285 rows=1 loops=1)"
"        Buffers: shared hit=7846"
"        ->  CTE Scan on password_stats_plpgsql  (cost=0.00..62.54 rows=3127 width=4) (actual time=38.261..38.280 rows=6 loops=1)"
"              Buffers: shared hit=7846"
"  SubPlan 2"
"    ->  CTE Scan on password_stats_plpgsql password_stats_plpgsql_1  (cost=0.00..70.36 rows=16 width=8) (actual time=0.002..0.002 rows=1 loops=1)"
"          Filter: (password_length = max_length_plpgsql.max_len)"
"          Rows Removed by Filter: 5"
"Planning:"
"  Buffers: shared hit=3"
"Planning Time: 0.189 ms"
"Execution Time: 38.348 ms"
```

## min distance test
```shell
ЗАМЕЧАНИЕ:  === Задача (б): Минимальное расстояние ===
ЗАМЕЧАНИЕ:  C-расширение: 54.688000 мс, минимальное расстояние: 1
ЗАМЕЧАНИЕ:  PL/pgSQL: 53.723000 мс, минимальное расстояние: 1
ЗАМЕЧАНИЕ:  Разница: PL/pgSQL медленнее в 0.98 раз
DO
```