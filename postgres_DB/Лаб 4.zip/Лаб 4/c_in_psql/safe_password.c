#include "postgres.h"
#include "fmgr.h"
#include "utils/builtins.h"
#include <string.h>
#include <ctype.h>

PG_MODULE_MAGIC;

PG_FUNCTION_INFO_V1(find_safe_password);

Datum find_safe_password(PG_FUNCTION_ARGS)
{
    text *input = PG_GETARG_TEXT_PP(0);
    char *str = text_to_cstring(input);
    char result[100] = {0};  // Максимальная длина пароля
    int result_pos = 0;
    int current_pos = 50;
    int len = strlen(str);
    int i = 0;
    
    while (i < len) {
        // Пропускаем пробелы
        if (str[i] == ' ') {
            i++;
            continue;
        }
        
        // Проверяем, что у нас достаточно символов для команды
        if (i + 2 >= len) break;
        
        char direction = str[i];
        if (direction != 'L' && direction != 'R') {
            i++;
            continue;
        }
        
        // Извлекаем число (2 цифры)
        char num_str[3] = {0};
        num_str[0] = str[i+1];
        num_str[1] = str[i+2];
        int steps = atoi(num_str);
        
        // Вычисляем новую позицию
        if (direction == 'L') {
            current_pos = (current_pos - steps) % 100;
        } else if (direction == 'R') {
            current_pos = (current_pos + steps) % 100;
        }
        
        // Приводим к диапазону 0-99
        current_pos = (current_pos + 100) % 100;
        
        // Если пришли на 0, запоминаем число поворотов
        if (current_pos == 0) {
            if (steps < 10) {
                result[result_pos++] = '0';
            }
            result[result_pos++] = '0' + (steps / 10);
            result[result_pos++] = '0' + (steps % 10);
        }
        
        i += 3;
    }
    
    pfree(str);
    PG_RETURN_TEXT_P(cstring_to_text(result));
}