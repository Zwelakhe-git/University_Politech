-- safe_password.sql
CREATE OR REPLACE FUNCTION find_safe_password(input text)
RETURNS text
AS 'safe_password', 'find_safe_password'
LANGUAGE C STRICT;