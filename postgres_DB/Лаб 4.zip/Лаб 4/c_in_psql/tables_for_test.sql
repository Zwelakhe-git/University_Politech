-- Создаем таблицу с полями для обоих методов
CREATE TABLE safe_combinations_test (
    id SERIAL PRIMARY KEY,
    combination TEXT NOT NULL,
    password_c TEXT,
    password_plpgsql TEXT,
    calc_time_c INTERVAL,
    calc_time_plpgsql INTERVAL
);

-- Генерируем 100,000 строк для теста (для 1,000,000 может быть долго)
INSERT INTO safe_combinations_test (combination)
SELECT generate_random_combination()
FROM generate_series(1, 100000);

