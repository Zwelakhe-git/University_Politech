#include "postgres.h"
#include "fmgr.h"

PG_MODULE_MAGIC;
PG_FUNCTION_INFO_V1(grayscale);

Datum grayscale(PG_FUNCTION_ARGS)
{
    float8 r = PG_GETARG_FLOAT8(0);
    float8 g = PG_GETARG_FLOAT8(1);
    float8 b = PG_GETARG_FLOAT8(2);

    PG_RETURN_FLOAT8(0.299 * r + 0.587 * g + 0.114 * b);
}