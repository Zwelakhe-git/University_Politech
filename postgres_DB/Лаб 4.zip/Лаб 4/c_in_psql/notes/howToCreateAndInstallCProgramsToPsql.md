# можно создать C файлы
```c
#include "postgres.h"
#include "fmgr.h"

PG_MODULE_MAGIC;
PG_FUNCTION_INFO_V1(grayscale);

Datum grayscale(PG_FUNCTION_ARGS)
{
    float8 r = PG_GETARG_FLOAT8(0);
    float8 g = PG_GETARG_FLOAT8(1);
    float8 b = PG_GETARG_FLOAT8(2);

    PG_RETURN_FLOAT8(0.299 * r + 0.587 * g + 0.114 * b);
}
```

## создать Makefile

```makefile
# Makefile
MODULES = grayscale # c filename или путь
PG_CONFIG = pg_config
PGXS := $(shell $(PG_CONFIG) --pgxs)
include $(PGXS)
```

## компилировать

```shell
make
```

должно выдавать файлы grayscale.[o,so,bc]

## установить в psql
```shell
sudo cp grayscale.so $(pg_config --pkglibdir)/
```

## подключаем к БД и создаем psql обертку для функции
```shell
psql -d bd_name
```

```sql
CREATE OR REPLACE FUNCTION grayscale(
    r double precision,
    g double precision,
    b double precision
) RETURNS double precision
AS 'grayscale', 'grayscale'
LANGUAGE C STRICT;
```
