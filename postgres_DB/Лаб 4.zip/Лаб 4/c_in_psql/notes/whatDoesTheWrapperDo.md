## lets look at the sql function после того, как мы копировали файлы в psql
```sql
CREATE OR REPLACE FUNCTION grayscale(
    r double precision,
    g double precision,
    b double precision
) RETURNS double precision
AS 'grayscale', 'grayscale'
LANGUAGE C STRICT;
```

AS 'grayscale', 'grayscale':

Первое 'grayscale' — имя shared library (.so файла)

Второе 'grayscale' — имя C-функции внутри этой библиотеки

PostgreSQL загружает grayscale.so и ищет в нем функцию grayscale

LANGUAGE C:

Указывает, что функция написана на C

PostgreSQL будет использовать C-ABI для вызова

STRICT:

Функция автоматически вернет NULL, если любой аргумент NULL

Без STRICT нужно проверять NULL вручную макросом PG_ARGISNULL(n)

```sql
SELECT grayscale(0.5, 0.3, 0.2);
```

Шаг 1: PostgreSQL парсит SQL → видит вызов grayscale(0.5, 0.3, 0.2)

Шаг 2: Проверяет, что функция существует → находит вашу обертку

Шаг 3: Загружает grayscale.so (если еще не загружен)

Шаг 4: Конвертирует SQL типы → C типы:

double precision (SQL) → float8 (C)

Макрос PG_GETARG_FLOAT8(0) извлекает аргумент

Шаг 5: Вызывает вашу C-функцию

Шаг 6: Конвертирует результат обратно:

PG_RETURN_FLOAT8(value) → SQL double precision