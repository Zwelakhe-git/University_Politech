# установить библиотеку
```shell
sudo apt update
sudo apt install [--reinstall] postgresql-server-dev-17

sudo apt install postgresql-server-dev-17 postgresql-common build-essential
```

## проверь файл
```shell
pg_config --pgxs
```