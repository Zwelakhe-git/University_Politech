-- Генератор случайных комбинаций
CREATE OR REPLACE FUNCTION generate_random_combination()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    result TEXT := '';
    num_commands INT;
    direction TEXT;
    steps INT;
    i INT;
BEGIN
    -- Случайное количество команд от 5 до 100
    num_commands := 5 + floor(random() * 95);
    
    FOR i IN 1..num_commands LOOP
        -- Случайное направление
        IF random() < 0.5 THEN
            direction := 'L';
        ELSE
            direction := 'R';
        END IF;
        
        -- Случайные шаги 0-99
        steps := floor(random() * 100);
        
        -- Добавляем команду
        result := result || direction || LPAD(steps::TEXT, 2, '0');
    END LOOP;
    
    RETURN result;
END;
$$;

-- Создаем таблицу для тестов
CREATE TABLE safe_combinations (
    id SERIAL PRIMARY KEY,
    combination TEXT NOT NULL,
    password_c TEXT,
    password_plpgsql TEXT
);

-- Генерируем 1,000,000 строк (может занять время)
INSERT INTO safe_combinations (combination)
SELECT generate_random_combination()
FROM generate_series(1, 1000000);