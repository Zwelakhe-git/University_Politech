-- Используем C-функцию
DO $$
DECLARE
    start_time timestamptz;
    end_time timestamptz;
BEGIN
    start_time := clock_timestamp();
    
    UPDATE safe_combinations 
    SET password_c = find_safe_password(combination);
    
    end_time := clock_timestamp();
    RAISE NOTICE 'C extension time: % ms', 
        extract(epoch from (end_time - start_time)) * 1000;
END;
$$;