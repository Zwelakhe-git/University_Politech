

-- Тестирование C-функции
DO $$
DECLARE
    start_time timestamptz;
    end_time timestamptz;
    row_count INT;
BEGIN
    -- C-функция
    start_time := clock_timestamp();
    
    UPDATE safe_combinations_test 
    SET password_c = find_safe_password(combination),
        calc_time_c = clock_timestamp() - start_time;
    
    end_time := clock_timestamp();
    
    GET DIAGNOSTICS row_count = ROW_COUNT;
    RAISE NOTICE 'C-расширение: % строк обработано за % миллисекунд', 
        row_count, EXTRACT(epoch FROM (end_time - start_time)) * 1000;
END;
$$;

-- Тестирование PL/pgSQL функции (v3)
DO $$
DECLARE
    start_time timestamptz;
    end_time timestamptz;
    row_count INT;
BEGIN
    start_time := clock_timestamp();
    
    UPDATE safe_combinations_test 
    SET password_plpgsql = find_safe_password_plpgsql(combination),
        calc_time_plpgsql = clock_timestamp() - start_time;
    
    end_time := clock_timestamp();
    
    GET DIAGNOSTICS row_count = ROW_COUNT;
    RAISE NOTICE 'PL/pgSQL: % строк обработано за % миллисекунд', 
        row_count, EXTRACT(epoch FROM (end_time - start_time)) * 1000;
END;
$$;


-- longest

-- Версия 1: Используем C-функцию
EXPLAIN (ANALYZE, BUFFERS, TIMING)
WITH password_stats_c AS (
    SELECT 
        LENGTH(password_c) / 2 as password_length,
        COUNT(*) as count
    FROM safe_combinations_test
    WHERE password_c IS NOT NULL AND password_c != ''
    GROUP BY LENGTH(password_c) / 2
),
max_length_c AS (
    SELECT MAX(password_length) as max_len FROM password_stats_c
)
SELECT 
    'C-расширение' as method,
    max_len as longest_password_length,
    (SELECT count FROM password_stats_c WHERE password_length = max_len) as count_of_passwords
FROM max_length_c;

-- Версия 2: Используем PL/pgSQL функцию
EXPLAIN (ANALYZE, BUFFERS, TIMING)
WITH password_stats_plpgsql AS (
    SELECT 
        LENGTH(password_plpgsql) / 2 as password_length,
        COUNT(*) as count
    FROM safe_combinations_test
    WHERE password_plpgsql IS NOT NULL AND password_plpgsql != ''
    GROUP BY LENGTH(password_plpgsql) / 2
),
max_length_plpgsql AS (
    SELECT MAX(password_length) as max_len FROM password_stats_plpgsql
)
SELECT 
    'PL/pgSQL' as method,
    max_len as longest_password_length,
    (SELECT count FROM password_stats_plpgsql WHERE password_length = max_len) as count_of_passwords
FROM max_length_plpgsql;

-- min distances
DO $$
DECLARE
    start_time timestamptz;
    end_time timestamptz;
    min_distance_c INT;
    min_distance_plpgsql INT;
    time_c NUMERIC;
    time_plpgsql NUMERIC;
BEGIN
    -- Задача (б) с C-расширением
    start_time := clock_timestamp();
    
    WITH true_passwords_c AS (
        SELECT 
            id,
            LAG(id) OVER (ORDER BY id) as prev_id
        FROM safe_combinations_test
        WHERE password_c != ''
    ),
    distances_c AS (
        SELECT id - prev_id as distance
        FROM true_passwords_c
        WHERE prev_id IS NOT NULL
    )
    SELECT MIN(distance) INTO min_distance_c FROM distances_c;
    
    end_time := clock_timestamp();
    time_c := EXTRACT(epoch FROM (end_time - start_time)) * 1000;
    
    -- Задача (б) с PL/pgSQL
    start_time := clock_timestamp();
    
    WITH true_passwords_plpgsql AS (
        SELECT 
            id,
            LAG(id) OVER (ORDER BY id) as prev_id
        FROM safe_combinations_test
        WHERE password_plpgsql != ''
    ),
    distances_plpgsql AS (
        SELECT id - prev_id as distance
        FROM true_passwords_plpgsql
        WHERE prev_id IS NOT NULL
    )
    SELECT MIN(distance) INTO min_distance_plpgsql FROM distances_plpgsql;
    
    end_time := clock_timestamp();
    time_plpgsql := EXTRACT(epoch FROM (end_time - start_time)) * 1000;
    
    -- Вывод результатов
    RAISE NOTICE '=== Задача (б): Минимальное расстояние ===';
    RAISE NOTICE 'C-расширение: % мс, минимальное расстояние: %', time_c, min_distance_c;
    RAISE NOTICE 'PL/pgSQL: % мс, минимальное расстояние: %', time_plpgsql, min_distance_plpgsql;
    RAISE NOTICE 'Разница: PL/pgSQL медленнее в % раз', round(time_plpgsql / time_c, 2);
END;
$$;