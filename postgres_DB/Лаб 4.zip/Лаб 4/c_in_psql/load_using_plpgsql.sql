DO $$
DECLARE
    start_time timestamptz;
    end_time timestamptz;
BEGIN
    start_time := clock_timestamp();
    
    UPDATE safe_combinations 
    SET password_plpgsql = find_safe_password_plpgsql(combination);
    
    end_time := clock_timestamp();
    RAISE NOTICE 'PL/pgSQL time: % ms', 
        extract(epoch from (end_time - start_time)) * 1000;
END;
$$;