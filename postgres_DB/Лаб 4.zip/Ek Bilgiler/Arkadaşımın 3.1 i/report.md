



# 2. оценка скорости выполнения запросов

```sql
-- Запросы для тестирования производительности
-- Запрос 1: К одной таблице с фильтрацией по нескольким полям
-- Простой запрос к одной таблице
EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT
    DATE_TRUNC('month', sale_date) AS month,
    COUNT(*) as total_sales,
    SUM(amount) as total_amount,
    AVG(amount) as avg_amount,
    COUNT(DISTINCT customer_id) as unique_customers
FROM sales
WHERE 
    sale_date BETWEEN '2024-01-01' AND '2024-12-31'
    AND amount > 1000
    AND payment_type IN ('card', 'online')
    AND NOT is_return
GROUP BY DATE_TRUNC('month', sale_date)
ORDER BY month;
```



![image-20260316133800047](C:\Users\ThunderPC\AppData\Roaming\Typora\typora-user-images\image-20260316133800047.png)

![image-20260316133829688](C:\Users\ThunderPC\AppData\Roaming\Typora\typora-user-images\image-20260316133829688.png)

```
"QUERY PLAN"
"GroupAggregate  (cost=19643.45..19643.48 rows=1 width=88) (actual time=130.354..134.497 rows=0 loops=1)"
"  Output: (date_trunc('month'::text, (sale_date)::timestamp with time zone)), count(*), sum(amount), avg(amount), count(DISTINCT customer_id)"
"  Group Key: (date_trunc('month'::text, (sales.sale_date)::timestamp with time zone))"
"  Buffers: shared hit=10313"
"  ->  Sort  (cost=19643.45..19643.45 rows=1 width=17) (actual time=130.351..134.494 rows=0 loops=1)"
"        Output: (date_trunc('month'::text, (sale_date)::timestamp with time zone)), amount, customer_id"
"        Sort Key: (date_trunc('month'::text, (sales.sale_date)::timestamp with time zone)), sales.customer_id"
"        Sort Method: quicksort  Memory: 25kB"
"        Buffers: shared hit=10313"
"        ->  Gather  (cost=1000.00..19643.44 rows=1 width=17) (actual time=130.305..134.447 rows=0 loops=1)"
"              Output: (date_trunc('month'::text, (sale_date)::timestamp with time zone)), amount, customer_id"
"              Workers Planned: 2"
"              Workers Launched: 2"
"              Buffers: shared hit=10310"
"              ->  Parallel Seq Scan on public.sales  (cost=0.00..18643.34 rows=1 width=17) (actual time=89.770..89.771 rows=0 loops=3)"
"                    Output: date_trunc('month'::text, (sale_date)::timestamp with time zone), amount, customer_id"
"                    Filter: ((NOT sales.is_return) AND (sales.sale_date >= '2024-01-01'::date) AND (sales.sale_date <= '2024-12-31'::date) AND (sales.amount > '1000'::numeric) AND ((sales.payment_type)::text = ANY ('{card,online}'::text[])))"
"                    Rows Removed by Filter: 333333"
"                    Buffers: shared hit=10310"
"                    Worker 0:  actual time=71.570..71.571 rows=0 loops=1"
"                      Buffers: shared hit=2037"
"                    Worker 1:  actual time=70.277..70.277 rows=0 loops=1"
"                      Buffers: shared hit=2054"
"Planning:"
"  Buffers: shared hit=66 read=1 dirtied=3"
"Planning Time: 20.346 ms"
"Execution Time: 134.651 ms"
```

- **время выполнения: 134.651мс**
- **Parallel Seq Scan**
- **Rows Removed by Filter: 333333**
- **Buffers: shared hit=10310**

**С индексами**

```
"GroupAggregate  (cost=8.47..8.50 rows=1 width=88) (actual time=0.045..0.046 rows=0 loops=1)"
"  Output: (date_trunc('month'::text, (sale_date)::timestamp with time zone)), count(*), sum(amount), avg(amount), count(DISTINCT customer_id)"
"  Group Key: (date_trunc('month'::text, (sales.sale_date)::timestamp with time zone))"
"  Buffers: shared hit=3 read=3"
"  ->  Sort  (cost=8.47..8.47 rows=1 width=17) (actual time=0.044..0.045 rows=0 loops=1)"
"        Output: (date_trunc('month'::text, (sale_date)::timestamp with time zone)), amount, customer_id"
"        Sort Key: (date_trunc('month'::text, (sales.sale_date)::timestamp with time zone)), sales.customer_id"
"        Sort Method: quicksort  Memory: 25kB"
"        Buffers: shared hit=3 read=3"
"        ->  Index Scan using idx_sales_composite on public.sales  (cost=0.42..8.46 rows=1 width=17) (actual time=0.032..0.032 rows=0 loops=1)"
"              Output: date_trunc('month'::text, (sale_date)::timestamp with time zone), amount, customer_id"
"              Index Cond: ((sales.sale_date >= '2024-01-01'::date) AND (sales.sale_date <= '2024-12-31'::date))"
"              Filter: ((NOT sales.is_return) AND (sales.amount > '1000'::numeric) AND ((sales.payment_type)::text = ANY ('{card,online}'::text[])))"
"              Buffers: shared read=3"
"Planning:"
"  Buffers: shared hit=126 read=10"
"Planning Time: 1.474 ms"
"Execution Time: 0.084 ms"
```

- **Index Scan using idx_sales_composite**
- **shared hit=3 read=3**

ускорение примерно в **1600 раз**



```sql
-- К нескольким связанным таблицам
-- Сложный запрос с JOIN
EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT 
    r.country,
    r.name as region_name,
    p.category_id,
    DATE_TRUNC('month', s.sale_date) as month,
    COUNT(*) as transaction_count,
    SUM(s.amount) as revenue,
    SUM(s.quantity) as items_sold,
    AVG(s.amount) as avg_transaction_value,
    COUNT(DISTINCT s.customer_id) as customers_count
FROM sales s
JOIN products p ON s.product_id = p.id
JOIN regions r ON s.region_id = r.id
LEFT JOIN time_dim t ON s.sale_date = t.date_key
WHERE 
    s.sale_date >= '2024-01-01'
    AND s.sale_date < '2025-01-01'
    AND p.category_id IN (1, 3, 5, 7)
    AND r.country IN ('Россия', 'Казахстан')
    AND s.amount > 500
    AND (t.is_weekend = true OR s.payment_type = 'online')
GROUP BY r.country, r.name, p.category_id, DATE_TRUNC('month', s.sale_date)
ORDER BY revenue DESC
LIMIT 100;
```



![Снимок экрана 2026-03-23 102254](F:\school\postgres\lab3\images\Снимок экрана 2026-03-23 102254.png)

![Снимок экрана 2026-03-23 102314](F:\school\postgres\lab3\images\Снимок экрана 2026-03-23 102314.png)

![Снимок экрана 2026-03-23 102329](F:\school\postgres\lab3\images\Снимок экрана 2026-03-23 102329.png)

![Снимок экрана 2026-03-23 102347](F:\school\postgres\lab3\images\Снимок экрана 2026-03-23 102347.png)

```
"QUERY PLAN"
"Limit  (cost=18665.87..18665.88 rows=1 width=536) (actual time=76.630..79.845 rows=0 loops=1)"
"  Output: r.country, r.name, p.category_id, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone)), (count(*)), (sum(s.amount)), (sum(s.quantity)), (avg(s.amount)), (count(DISTINCT s.customer_id))"
"  Buffers: shared hit=238 read=10118"
"  ->  Sort  (cost=18665.87..18665.88 rows=1 width=536) (actual time=76.627..79.841 rows=0 loops=1)"
"        Output: r.country, r.name, p.category_id, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone)), (count(*)), (sum(s.amount)), (sum(s.quantity)), (avg(s.amount)), (count(DISTINCT s.customer_id))"
"        Sort Key: (sum(s.amount)) DESC"
"        Sort Method: quicksort  Memory: 25kB"
"        Buffers: shared hit=238 read=10118"
"        ->  GroupAggregate  (cost=18629.30..18665.86 rows=1 width=536) (actual time=76.620..79.833 rows=0 loops=1)"
"              Output: r.country, r.name, p.category_id, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone)), count(*), sum(s.amount), sum(s.quantity), avg(s.amount), count(DISTINCT s.customer_id)"
"              Group Key: r.country, r.name, p.category_id, date_trunc('month'::text, (s.sale_date)::timestamp with time zone)"
"              Buffers: shared hit=238 read=10118"
"              ->  Nested Loop Left Join  (cost=18629.30..18665.82 rows=1 width=461) (actual time=76.617..79.829 rows=0 loops=1)"
"                    Output: r.country, r.name, p.category_id, date_trunc('month'::text, (s.sale_date)::timestamp with time zone), s.amount, s.quantity, s.customer_id"
"                    Inner Unique: true"
"                    Join Filter: (s.sale_date = t.date_key)"
"                    Filter: (t.is_weekend OR ((s.payment_type)::text = 'online'::text))"
"                    Buffers: shared hit=238 read=10118"
"                    ->  Gather Merge  (cost=18629.30..18629.42 rows=1 width=462) (actual time=76.616..79.826 rows=0 loops=1)"
"                          Output: s.sale_date, s.amount, s.quantity, s.customer_id, s.payment_type, p.category_id, r.country, r.name"
"                          Workers Planned: 2"
"                          Workers Launched: 2"
"                          Buffers: shared hit=238 read=10118"
"                          ->  Sort  (cost=17629.27..17629.28 rows=1 width=462) (actual time=68.487..68.490 rows=0 loops=3)"
"                                Output: s.sale_date, s.amount, s.quantity, s.customer_id, s.payment_type, p.category_id, r.country, r.name, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone))"
"                                Sort Key: r.country, r.name, p.category_id, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone)), s.customer_id"
"                                Sort Method: quicksort  Memory: 25kB"
"                                Buffers: shared hit=238 read=10118"
"                                Worker 0:  actual time=64.490..64.493 rows=0 loops=1"
"                                  Sort Method: quicksort  Memory: 25kB"
"                                  Buffers: shared hit=105 read=2446"
"                                Worker 1:  actual time=65.410..65.412 rows=0 loops=1"
"                                  Sort Method: quicksort  Memory: 25kB"
"                                  Buffers: shared hit=117 read=4826"
"                                ->  Nested Loop  (cost=0.28..17629.26 rows=1 width=462) (actual time=67.736..67.737 rows=0 loops=3)"
"                                      Output: s.sale_date, s.amount, s.quantity, s.customer_id, s.payment_type, p.category_id, r.country, r.name, date_trunc('month'::text, (s.sale_date)::timestamp with time zone)"
"                                      Inner Unique: true"
"                                      Join Filter: (r.id = s.region_id)"
"                                      Buffers: shared hit=192 read=10118"
"                                      Worker 0:  actual time=64.403..64.405 rows=0 loops=1"
"                                        Buffers: shared hit=82 read=2446"
"                                      Worker 1:  actual time=63.275..63.277 rows=0 loops=1"
"                                        Buffers: shared hit=94 read=4826"
"                                      ->  Nested Loop  (cost=0.28..17617.99 rows=1 width=30) (actual time=67.735..67.736 rows=0 loops=3)"
"                                            Output: s.sale_date, s.amount, s.quantity, s.customer_id, s.region_id, s.payment_type, p.category_id"
"                                            Inner Unique: true"
"                                            Buffers: shared hit=192 read=10118"
"                                            Worker 0:  actual time=64.402..64.404 rows=0 loops=1"
"                                              Buffers: shared hit=82 read=2446"
"                                            Worker 1:  actual time=63.275..63.276 rows=0 loops=1"
"                                              Buffers: shared hit=94 read=4826"
"                                            ->  Parallel Seq Scan on public.sales s  (cost=0.00..17601.67 rows=1 width=30) (actual time=67.734..67.734 rows=0 loops=3)"
"                                                  Output: s.id, s.product_id, s.category_id, s.region_id, s.sale_date, s.amount, s.quantity, s.customer_id, s.payment_type, s.is_return, s.created_at"
"                                                  Filter: ((s.sale_date >= '2024-01-01'::date) AND (s.sale_date < '2025-01-01'::date) AND (s.amount > '500'::numeric))"
"                                                  Rows Removed by Filter: 333333"
"                                                  Buffers: shared hit=192 read=10118"
"                                                  Worker 0:  actual time=64.401..64.402 rows=0 loops=1"
"                                                    Buffers: shared hit=82 read=2446"
"                                                  Worker 1:  actual time=63.273..63.274 rows=0 loops=1"
"                                                    Buffers: shared hit=94 read=4826"
"                                            ->  Index Scan using products_pkey on public.products p  (cost=0.28..8.30 rows=1 width=8) (never executed)"
"                                                  Output: p.id, p.name, p.category_id, p.price, p.supplier_id, p.description, p.full_text_search, p.keywords"
"                                                  Index Cond: (p.id = s.product_id)"
"                                                  Filter: (p.category_id = ANY ('{1,3,5,7}'::integer[]))"
"                                      ->  Seq Scan on public.regions r  (cost=0.00..11.25 rows=2 width=440) (never executed)"
"                                            Output: r.id, r.name, r.country, r.manager, r.description, r.full_text_search"
"                                            Filter: ((r.country)::text = ANY ('{Россия,Казахстан}'::text[]))"
"                    ->  Seq Scan on public.time_dim t  (cost=0.00..19.96 rows=1096 width=5) (never executed)"
"                          Output: t.date_key, t.year, t.quarter, t.month, t.week, t.day, t.is_weekend, t.season"
"Planning:"
"  Buffers: shared hit=14"
"Planning Time: 1.631 ms"
"Execution Time: 80.115 ms"
```

- **время выполнения: 80.115мс**
- **[Seq,parallel]  Scan**

**с индексами**

```
"Limit  (cost=23.26..23.26 rows=1 width=536) (actual time=0.020..0.021 rows=0 loops=1)"
"  Output: r.country, r.name, p.category_id, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone)), (count(*)), (sum(s.amount)), (sum(s.quantity)), (avg(s.amount)), (count(DISTINCT s.customer_id))"
"  Buffers: shared hit=1"
"  ->  Sort  (cost=23.26..23.26 rows=1 width=536) (actual time=0.019..0.020 rows=0 loops=1)"
"        Output: r.country, r.name, p.category_id, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone)), (count(*)), (sum(s.amount)), (sum(s.quantity)), (avg(s.amount)), (count(DISTINCT s.customer_id))"
"        Sort Key: (sum(s.amount)) DESC"
"        Sort Method: quicksort  Memory: 25kB"
"        Buffers: shared hit=1"
"        ->  GroupAggregate  (cost=23.20..23.25 rows=1 width=536) (actual time=0.016..0.017 rows=0 loops=1)"
"              Output: r.country, r.name, p.category_id, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone)), count(*), sum(s.amount), sum(s.quantity), avg(s.amount), count(DISTINCT s.customer_id)"
"              Group Key: r.country, r.name, p.category_id, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone))"
"              Buffers: shared hit=1"
"              ->  Sort  (cost=23.20..23.21 rows=1 width=461) (actual time=0.015..0.016 rows=0 loops=1)"
"                    Output: r.country, r.name, p.category_id, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone)), s.amount, s.quantity, s.customer_id"
"                    Sort Key: r.country, r.name, p.category_id, (date_trunc('month'::text, (s.sale_date)::timestamp with time zone)), s.customer_id"
"                    Sort Method: quicksort  Memory: 25kB"
"                    Buffers: shared hit=1"
"                    ->  Nested Loop Left Join  (cost=0.85..23.19 rows=1 width=461) (actual time=0.010..0.011 rows=0 loops=1)"
"                          Output: r.country, r.name, p.category_id, date_trunc('month'::text, (s.sale_date)::timestamp with time zone), s.amount, s.quantity, s.customer_id"
"                          Inner Unique: true"
"                          Filter: (t.is_weekend OR ((s.payment_type)::text = 'online'::text))"
"                          Buffers: shared hit=1"
"                          ->  Nested Loop  (cost=0.57..18.88 rows=1 width=462) (actual time=0.010..0.010 rows=0 loops=1)"
"                                Output: s.sale_date, s.amount, s.quantity, s.customer_id, s.payment_type, p.category_id, r.country, r.name"
"                                Inner Unique: true"
"                                Join Filter: (r.id = s.region_id)"
"                                Buffers: shared hit=1"
"                                ->  Nested Loop  (cost=0.57..16.60 rows=1 width=30) (actual time=0.010..0.010 rows=0 loops=1)"
"                                      Output: s.sale_date, s.amount, s.quantity, s.customer_id, s.region_id, s.payment_type, p.category_id"
"                                      Join Filter: (p.id = s.product_id)"
"                                      Buffers: shared hit=1"
"                                      ->  Index Scan using idx_products_category on public.products p  (cost=0.15..8.15 rows=1 width=8) (actual time=0.009..0.009 rows=0 loops=1)"
"                                            Output: p.id, p.name, p.category_id, p.price, p.supplier_id, p.description, p.full_text_search, p.keywords"
"                                            Index Cond: (p.category_id = ANY ('{1,3,5,7}'::integer[]))"
"                                            Buffers: shared hit=1"
"                                      ->  Index Scan using idx_sales_composite on public.sales s  (cost=0.42..8.45 rows=1 width=30) (never executed)"
"                                            Output: s.id, s.product_id, s.category_id, s.region_id, s.sale_date, s.amount, s.quantity, s.customer_id, s.payment_type, s.is_return, s.created_at"
"                                            Index Cond: ((s.sale_date >= '2024-01-01'::date) AND (s.sale_date < '2025-01-01'::date))"
"                                ->  Seq Scan on public.regions r  (cost=0.00..2.25 rows=2 width=440) (never executed)"
"                                      Output: r.id, r.name, r.country, r.manager, r.description, r.full_text_search"
"                                      Filter: ((r.country)::text = ANY ('{Россия,Казахстан}'::text[]))"
"                          ->  Index Only Scan using idx_time_dim_date on public.time_dim t  (cost=0.28..4.29 rows=1 width=5) (never executed)"
"                                Output: t.date_key, t.is_weekend"
"                                Index Cond: (t.date_key = s.sale_date)"
"                                Heap Fetches: 0"
"Planning:"
"  Buffers: shared hit=30"
"Planning Time: 0.908 ms"
"Execution Time: 0.073 ms"
```

- **Execution Time: 0.073 ms**
- **Index Scan using idx_sales_composite, idx_products_category**

# 3. оценка скорости полнотекстового поиска (использование функций to_tsvector to_tsquery)

```sql
-- Добавляем текстовые поля в существующие таблицы
ALTER TABLE products ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS full_text_search TSVECTOR;
ALTER TABLE products ADD COLUMN IF NOT EXISTS keywords TEXT[];

ALTER TABLE regions ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE regions ADD COLUMN IF NOT EXISTS full_text_search TSVECTOR;

-- Создаем таблицу для отзывов/комментариев
CREATE TABLE IF NOT EXISTS product_reviews (
    id BIGSERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id),
    customer_id INTEGER,
    review_text TEXT NOT NULL,
    review_tsv TSVECTOR,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Создаем таблицу для поисковых запросов
CREATE TABLE IF NOT EXISTS search_log (
    id BIGSERIAL PRIMARY KEY,
    query_text TEXT,
    results_count INTEGER,
    search_tsv TSVECTOR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

```sql
-- Функция для генерации текстовых данных на PL/Python3u
CREATE OR REPLACE FUNCTION generate_text_data()
RETURNS TEXT
AS $$
	import random
	import uuid
	
	# Словари для генерации текста
	product_adjectives = [
		'качественный', 'надежный', 'современный', 'стильный', 'компактный',
		'мощный', 'экономичный', 'инновационный', 'профессиональный', 'универсальный'
	]
	
	product_nouns = [
		'смартфон', 'ноутбук', 'планшет', 'телевизор', 'холодильник',
		'стиральная машина', 'кофеварка', 'пылесос', 'микроволновка', 'фен'
	]
	
	features = [
		'Wi-Fi', 'Bluetooth', 'USB', 'HDMI', 'сенсорный экран',
		'голосовое управление', 'таймер', 'регулировка температуры',
		'защита от детей', 'энергосбережение'
	]
	
	pros = [
		'отличное качество', 'быстрая доставка', 'хорошая упаковка',
		'понятная инструкция', 'длительная гарантия', 'низкое энергопотребление',
		'тихая работа', 'простота использования', 'красивый дизайн', 'эргономичность'
	]
	
	cons = [
		'высокая цена', 'долгая доставка', 'сложная настройка',
		'шумная работа', 'большой вес', 'непонятное меню',
		'хлипкая упаковка', 'короткий шнур', 'нет русской инструкции'
	]
	
	try:
		# Обновляем описания продуктов
		products = plpy.execute("SELECT id FROM products")
		
		for product in products:
			product_id = product['id']
			
			# Генерируем описание продукта
			adj = random.choice(product_adjectives)
			noun = random.choice(product_nouns)
			feat = random.sample(features, k=random.randint(2, 5))
			
			description = f"{adj.capitalize()} {noun} с функциями: {', '.join(feat)}. "
			description += f"Идеально подходит для {random.choice(['дома', 'офиса', 'путешествий'])}. "
			description += f"Гарантия {random.randint(1, 5)} года."
			
			# Генерируем ключевые слова
			keywords = [adj, noun] + feat[:2]
			
			# Обновляем продукт
			plan = plpy.prepare("UPDATE products SET description = $1,keywords = $2 WHERE id = $3", ["text","text[]","int"])
			plpy.execute(plan,[description, keywords, product_id])
			
		# Генерируем отзывы
		products = plpy.execute("SELECT id FROM products LIMIT 500")
		reviews_count = 0
		
		for product in products:
			product_id = product['id']
			# Для каждого продукта генерируем 1-10 отзывов
			for _ in range(random.randint(1, 10)):
				rating = random.randint(1, 5)
				
				# Формируем текст отзыва в зависимости от рейтинга
				if rating >= 4:
					pos_pros = random.sample(pros, k=random.randint(1, 3))
					review = f"Отличный товар! {' '.join(pos_pros)}. "
					if random.random() > 0.5:
						review += f"Недостатки: {random.choice(cons)}."
				elif rating == 3:
					review = f"Нормальный товар за свою цену. {random.choice(pros)}. "
					review += f"Но {random.choice(cons)}."
				else:
					neg_cons = random.sample(cons, k=random.randint(1, 3))
					review = f"Разочарован. {' '.join(neg_cons)}. "
					review += f"Единственный плюс: {random.choice(pros)}."
				
				# Добавляем случайные детали
				if random.random() > 0.7:
					review += f" Покупал {random.choice(['для себя', 'в подарок', 'для работы'])}."
				
				plan = plpy.prepare("INSERT INTO product_reviews (product_id, customer_id, review_text, rating) VALUES ($1, $2, $3, $4)", ["int","int","text","int"])
				plpy.execute(plan, [product_id, random.randint(1, 1000), review, rating])
				reviews_count += 1
		
		return f"Текстовые данные сгенерированы. Создано отзывов: {reviews_count}"
		
	except Exception as e:
		plpy.error(f"Ошибка при генерации текстовых данных: {e}")
$$ LANGUAGE plpython3u;

SELECT generate_text_data();
```



```sql
CREATE OR REPLACE FUNCTION update_tsvectors()
RETURNS TEXT
AS $$
	try:
		# Обновляем tsvector для продуктов (русский язык)
		plpy.execute("UPDATE products SET full_text_search = setweight(to_tsvector('russian', COALESCE(name, '')), 'A') || setweight(to_tsvector('russian', COALESCE(description, '')), 'B') || setweight(to_tsvector('russian', array_to_string(COALESCE(keywords, ARRAY[]::TEXT[]), ' ')), 'C') WHERE id IS NOT NULL")
		
		# Обновляем tsvector для регионов
		plpy.execute("UPDATE regions SET full_text_search = setweight(to_tsvector('russian', COALESCE(name, '')), 'A') || setweight(to_tsvector('russian', COALESCE(description, '')), 'B') || setweight(to_tsvector('russian', COALESCE(country, '')), 'C')")
		
		# Обновляем tsvector для отзывов
		plpy.execute("UPDATE product_reviews SET review_tsv = to_tsvector('russian', COALESCE(review_text, '')) WHERE id IS NOT NULL")
		
		# Проверяем количество обновленных записей
		products_count = plpy.execute("SELECT COUNT(*) FROM products WHERE full_text_search IS NOT NULL")[0]['count']
		reviews_count = plpy.execute("SELECT COUNT(*) FROM product_reviews WHERE review_tsv IS NOT NULL")[0]['count']
		
		return f"TSVectors обновлены. Продуктов: {products_count}, Отзывов: {reviews_count}"
		
	except Exception as e:
		plpy.error(f"Ошибка при обновлении tsvectors: {e}")
$$ LANGUAGE plpython3u;

SELECT update_tsvectors();
```



**оиск по продуктам (одна таблица)**

```sql
-- Поиск продуктов по описанию
SELECT 
    id,
    name,
    description,
    ts_rank(full_text_search, query) AS rank
FROM 
    products, 
    to_tsquery('russian', 'качественный & (смартфон | ноутбук) & !дорогой') query
WHERE 
    full_text_search @@ query
ORDER BY rank DESC
LIMIT 20;
```

```
"Limit  (cost=162.98..163.03 rows=20 width=253) (actual time=1.279..1.289 rows=16 loops=1)"
"  Output: products.id, products.name, products.description, (ts_rank(products.full_text_search, '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery))"
"  Buffers: shared hit=153"
"  ->  Sort  (cost=162.98..163.03 rows=20 width=253) (actual time=1.277..1.281 rows=16 loops=1)"
"        Output: products.id, products.name, products.description, (ts_rank(products.full_text_search, '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery))"
"        Sort Key: (ts_rank(products.full_text_search, '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery)) DESC"
"        Sort Method: quicksort  Memory: 31kB"
"        Buffers: shared hit=153"
"        ->  Seq Scan on public.products  (cost=0.00..162.55 rows=20 width=253) (actual time=0.285..1.229 rows=16 loops=1)"
"              Output: products.id, products.name, products.description, ts_rank(products.full_text_search, '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery)"
"              Filter: (products.full_text_search @@ '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery)"
"              Rows Removed by Filter: 984"
"              Buffers: shared hit=150"
"Planning:"
"  Buffers: shared hit=18"
"Planning Time: 0.441 ms"
"Execution Time: 1.322 ms"
```

- **Execution Time: 1.322 ms**
- **Seq Scan on public.products**
- **Buffers: shared hit=18**

План выполнения показывает использование Seq Scan, что означает полный перебор таблицы products. Это связано с отсутствием индекса по полю full_text_search. Условие full_text_search @@ query вычисляется для каждой строки, что приводит к значительным затратам времени при увеличении объема данных.

**Поиск по связанным таблицам**

```sql
-- Поиск продуктов с отзывами, содержащими определенные слова
WITH product_ranks AS (
    SELECT 
        p.id,
        p.name,
        p.description,
        p.full_text_search,
        ts_rank(p.full_text_search, query) AS product_rank
    FROM 
        products p,
        to_tsquery('russian', '(отличный | качественный) & товар & (доставка | упаковка)') query
    WHERE 
        p.full_text_search @@ query
),
review_stats AS (
    SELECT 
        pr.product_id,
        AVG(pr.rating) as avg_rating,
        COUNT(pr.id) as reviews_count,
        AVG(ts_rank(pr.review_tsv, query)) AS avg_review_rank
    FROM 
        product_reviews pr,
        to_tsquery('russian', '(отличный | качественный) & товар & (доставка | упаковка)') query
    WHERE 
        pr.review_tsv @@ query
    GROUP BY pr.product_id
)
SELECT 
    p.id,
    p.name,
    p.description,
    COALESCE(rs.avg_rating, 0) as avg_rating,
    COALESCE(rs.reviews_count, 0) as reviews_count,
    COALESCE(pr.product_rank, 0) as product_rank,
    COALESCE(rs.avg_review_rank, 0) as review_rank
FROM 
    products p
    LEFT JOIN product_ranks pr ON p.id = pr.id
    LEFT JOIN review_stats rs ON p.id = rs.product_id
WHERE 
    pr.id IS NOT NULL OR rs.product_id IS NOT NULL
ORDER BY 
    (COALESCE(pr.product_rank, 0) + COALESCE(rs.avg_review_rank, 0)) DESC
LIMIT 20;
```

```
"Limit  (cost=78.41..78.46 rows=20 width=253) (actual time=0.143..0.147 rows=16 loops=1)"
"  Output: products.id, products.name, products.description, (ts_rank(products.full_text_search, '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery))"
"  Buffers: shared hit=25"
"  ->  Sort  (cost=78.41..78.46 rows=20 width=253) (actual time=0.141..0.143 rows=16 loops=1)"
"        Output: products.id, products.name, products.description, (ts_rank(products.full_text_search, '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery))"
"        Sort Key: (ts_rank(products.full_text_search, '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery)) DESC"
"        Sort Method: quicksort  Memory: 31kB"
"        Buffers: shared hit=25"
"        ->  Bitmap Heap Scan on public.products  (cost=21.96..77.98 rows=20 width=253) (actual time=0.078..0.125 rows=16 loops=1)"
"              Output: products.id, products.name, products.description, ts_rank(products.full_text_search, '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery)"
"              Recheck Cond: (products.full_text_search @@ '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery)"
"              Heap Blocks: exact=16"
"              Buffers: shared hit=25"
"              ->  Bitmap Index Scan on idx_products_fts_gin  (cost=0.00..21.96 rows=20 width=0) (actual time=0.060..0.060 rows=16 loops=1)"
"                    Index Cond: (products.full_text_search @@ '''качествен'' & ( ''смартфон'' | ''ноутбук'' ) & !''дорог'''::tsquery)"
"                    Buffers: shared hit=9"
"Planning:"
"  Buffers: shared hit=1"
"Planning Time: 0.167 ms"
"Execution Time: 0.172 ms"
```

- **Execution Time: 0.172 ms**
- **Bitmap Heap Scan on public.products, Bitmap Index Scan on idx_products_fts_gin**
- **buffers: shared hit=1**

После создания GIN-индекса PostgreSQL использует Bitmap Heap/Index Scan, что позволяет быстро найти строки, удовлетворяющие условию полнотекстового поиска. Это существенно снижает количество читаемых строк и уменьшает нагрузку на диск.
