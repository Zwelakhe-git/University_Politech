

```sql
-- psql
SELECT pid,state,query
FROM pg_stat_activity WHERE state != 'idle'
```
```sql
SELECT
    pid,
    relation::regclass,
    mode,
    granted
FROM pg_locks
WHERE relation IS NOT NULL;
```

```sql
SELECT pg_terminate_backend(<pid>)
```