import random
from time import sleep
"""
    here i write my python scripts before putting them into postgres
"""
try:
   # plpy.execute("ALTER TABLE users ADD email VARCHAR(255) UNIQUE")
    def find(lst: list, cb):
        if len(lst) == 0: return None
        for el in lst:
            print(f"searching for {el['name']}, {el['email']}")
            if cb(el):
                print(f"found: {el['name']}, {el['email']}")
                return el
        return None
    names = [
        "Иван Петров", 
        "Мария Сидорова",
        "Алексей Смирнов",
        "Елена Козлова", 
        "Дмитрий Волков"
    ]
    emails = [
        "ivan.petrov@example.com"
        "maria.s@example.com",
        "alex.smirnov@mail.ru",
        "elena.koz@yandex.ru",
        "d.volkov@outlook.com"
    ]
    roles = ['guest', 'admin']
    users = []
    for n,e in zip(names, emails):
        users.append({"name": n, "email": e, "role": random.choice(roles)})
    print(random.choices(names, weights=[0.3, 0.4, 0.1, 0.2, 0.1]))
    #for user in users:
        #plan = plpy.prepare("INSERT INTO users (name, email, role) VALUES ($1,$2,$2)",["text","text","text"])
       # plpy.execute(plan, [user['name'], user['email'], user['role']])
except Exception as e:
    print(e)
    #plpy.error(f"error while executing request: {e}")

