-- =================================================================
-- Практикум СУБД — Задания 1.4 и 2.1
-- База данных: labone (Автосервис)
-- Таблицы: cars, masters, services, works, masters_earnings
-- =================================================================
-- Этот файл НЕ пересоздаёт таблицы — они уже существуют.
-- Только создаёт вспомогательную процедуру сброса тестовых данных.
-- =================================================================

-- Проверка таблиц
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;

-- Просмотр данных
SELECT * FROM cars     LIMIT 5;
SELECT * FROM masters  LIMIT 5;
SELECT * FROM services LIMIT 5;
SELECT * FROM works    LIMIT 5;

-- =================================================================
-- Процедура сброса тестовых данных между тестами аномалий
-- Вызов: CALL reset_test_data();
-- =================================================================
CREATE OR REPLACE PROCEDURE reset_test_data()
LANGUAGE plpgsql AS $$
BEGIN
    -- Удаляем тестовые строки если есть
    DELETE FROM works WHERE id IN (9901, 9902);

    -- Вставляем две тестовые строки с фиксированными id
    INSERT INTO works (id, date_work, master_id, car_id, service_id)
    VALUES
        (9901, CURRENT_DATE, 1, 1, 1),
        (9902, CURRENT_DATE, 2, 2, 2);

    RAISE NOTICE 'Тестовые данные сброшены: works id=9901 (service_id=1), id=9902 (service_id=2)';
END;
$$;

-- Инициализация
CALL reset_test_data();

SELECT id, date_work, master_id, car_id, service_id
FROM works WHERE id IN (9901, 9902);

SELECT 'Готово! Перед каждым тестом вызывать: CALL reset_test_data();' AS info;
