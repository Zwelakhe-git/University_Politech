-- Задание 1.4 - Аномалии транзакций
-- БД: labone, таблица works (id, date_work, master_id, car_id, service_id)
-- Перед каждым тестом сбрасывать данные:
--   DELETE FROM works WHERE id IN (9901, 9902);
--   INSERT INTO works (id, date_work, master_id, car_id, service_id)
--   VALUES (9901, CURRENT_DATE, 1, 1, 1), (9902, CURRENT_DATE, 2, 2, 2);

-- Уровни изоляции и аномалии:
-- READ COMMITTED  - грязного чтения нет, неповт. чтение и фантом есть
-- REPEATABLE READ - неповт. чтения нет, фантомов нет (в PostgreSQL через MVCC)
-- SERIALIZABLE    - всё предотвращается, конфликтующая транзакция откатывается


-- =============================================
-- ЧАСТЬ 1: READ COMMITTED
-- =============================================

-- Тест 1.1 - Грязное чтение (Dirty Read)
-- Ожидаем: аномалии НЕТ

-- Сброс тестовых данных перед тестом
DELETE FROM works WHERE id IN (9901, 9902);
-- DELETE: WHERE koşulunu sağlayan satırları siler
-- IN (9901, 9902): id'si 9901 veya 9902 olan satırları hedefler

INSERT INTO works (id, date_work, master_id, car_id, service_id)
VALUES (9901, CURRENT_DATE, 1, 1, 1), (9902, CURRENT_DATE, 2, 2, 2);
-- INSERT INTO: tabloya yeni satır ekler
-- CURRENT_DATE: bugünün tarihini otomatik döndürür
-- VALUES: virgülle ayrılarak birden fazla satır tek seferde eklenebilir

-- Сеанс A:
BEGIN ISOLATION LEVEL READ COMMITTED;
-- BEGIN: transaction başlatır
-- ISOLATION LEVEL READ COMMITTED: bu transaction sadece başka transactionların
--   COMMIT ettiği verileri görebilir, commit edilmemiş değişiklikler görünmez


UPDATE works SET service_id = 3 WHERE id = 9901;
-- UPDATE: mevcut satırı günceller
-- SET service_id = 3: ilgili sütunun değerini değiştirir
-- WHERE id = 9901: sadece bu satırı etkiler
-- satır COMMIT veya ROLLBACK'e kadar kilitlenir, diğer transactionlar bekler

-- не фиксируем, переходим в Сеанс B

-- Сеанс B:
-- BEGIN ISOLATION LEVEL READ COMMITTED;
-- SELECT id, service_id FROM works WHERE id = 9901;
-- SELECT: tablodan veri okur
-- должно быть 1, а не 3 - грязного чтения нет
-- READ COMMITTED commit edilmemiş değişiklikleri göstermez, bu yüzden hâlâ 1 görünür

-- Сеанс A:
ROLLBACK;
-- ROLLBACK: transaction'daki tüm değişiklikleri geri alır, veri başlangıç haline döner

-- Сеанс B:
-- SELECT id, service_id FROM works WHERE id = 9901; -- 1
-- COMMIT;
-- COMMIT: transaction'ı onaylar, değişiklikler kalıcı hale gelir

-- Вывод: грязных чтений в PostgreSQL нет даже на READ UNCOMMITTED


-- Тест 1.2 - Потерянное изменение (Lost Update)
-- Ожидаем: аномалии НЕТ (PostgreSQL блокирует строку)

SELECT id, name, cost_our FROM services WHERE id = 1;
-- mevcut değeri okuyoruz: cost_our = 1500

-- Сеанс A:
BEGIN ISOLATION LEVEL READ COMMITTED;
UPDATE services SET cost_our = cost_our + 500 WHERE id = 1;
-- cost_our + 500: mevcut değeri okuyup üstüne 500 ekler (increment)
-- satır satır seviyesinde kilitlenir (row-level lock)
-- aynı satıra başka bir UPDATE transaction bitene kadar beklemek zorunda kalır

SELECT id, name, cost_our FROM services WHERE id = 1;
-- transaction A içinden bakınca: cost_our = 2000 görünür (1500 + 500)

-- Сеанс B (параллельно, будет ждать блокировки):
-- BEGIN ISOLATION LEVEL READ COMMITTED;
-- UPDATE services SET cost_our = cost_our + 1000 WHERE id = 1;
-- satır A tarafından kilitli, Seans B bekler

-- Сеанс A:
COMMIT;
-- COMMIT sonrası kilit kalkar, Seans B devam eder
-- Seans B güncel değer olan 2000'i okur ve 1000 ekler

-- Сеанс B - разблокируется:
-- COMMIT;
-- SELECT id, name, cost_our FROM services WHERE id = 1; -- должно быть 3000

-- Восстанавливаем исходное значение:
UPDATE services SET cost_our = 1500 WHERE id = 1;

-- Вывод: потерянных изменений нет, оба инкремента сохранились (1500+500+1000=3000)


-- Тест 1.3 - Неповторяющееся чтение (Non-Repeatable Read)
-- Ожидаем: АНОМАЛИЯ ЕСТЬ на READ COMMITTED

DELETE FROM works WHERE id IN (9901, 9902);
INSERT INTO works (id, date_work, master_id, car_id, service_id)
VALUES (9901, CURRENT_DATE, 1, 1, 1), (9902, CURRENT_DATE, 2, 2, 2);

-- Сеанс A:
BEGIN ISOLATION LEVEL READ COMMITTED;
SELECT id, service_id FROM works WHERE id = 9901;
-- ilk okuma: service_id = 1
-- READ COMMITTED'da snapshot her sorgu için ayrı ayrı alınır,
-- transaction başlangıcında değil — bu yüzden anomali mümkün

-- Сеанс B:
-- BEGIN ISOLATION LEVEL READ COMMITTED;
-- UPDATE works SET service_id = 3 WHERE id = 9901;
-- COMMIT;
-- Seans B değişikliği commit etti, artık tabloda service_id = 3

-- Сеанс A - второй SELECT:
SELECT id, service_id FROM works WHERE id = 9901;
-- ANOMALİ: service_id = 3, aynı transaction içinde aynı sorgu farklı sonuç verdi
-- buna "non-repeatable read" denir
COMMIT;


-- Тест 1.4 - Фантомное чтение (Phantom Read)
-- Ожидаем: АНОМАЛИЯ ЕСТЬ на READ COMMITTED

DELETE FROM works WHERE id IN (9901, 9902);
INSERT INTO works (id, date_work, master_id, car_id, service_id)
VALUES (9901, CURRENT_DATE, 1, 1, 1), (9902, CURRENT_DATE, 2, 2, 2);

-- Сеанс A:
BEGIN ISOLATION LEVEL READ COMMITTED;
SELECT COUNT(*) AS cnt FROM works WHERE master_id = 1;
-- COUNT(*): koşulu sağlayan satır sayısını döndürür
-- AS cnt: sonuç sütununa takma ad verir
-- N değerini aklında tut

-- Сеанс B:
-- BEGIN ISOLATION LEVEL READ COMMITTED;
-- INSERT INTO works (date_work, master_id, car_id, service_id)
-- VALUES (CURRENT_DATE, 1, 1, 1);
-- COMMIT;
-- Seans B master_id=1 ile yeni satır ekledi ve commit etti

-- Сеанс A - второй COUNT:
SELECT COUNT(*) AS cnt FROM works WHERE master_id = 1;
-- ANOMALİ: cnt = N+1, "hayalet" satır belirdi
-- READ COMMITTED'da her sorgu fresh snapshot alır, yeni satırlar görünür
COMMIT;


-- =============================================
-- ЧАСТЬ 2: REPEATABLE READ
-- =============================================

-- Тест 2.1 - Неповторяющееся чтение на REPEATABLE READ
-- Ожидаем: аномалии НЕТ

DELETE FROM works WHERE id IN (9901, 9902);
INSERT INTO works (id, date_work, master_id, car_id, service_id)
VALUES (9901, CURRENT_DATE, 1, 1, 1), (9902, CURRENT_DATE, 2, 2, 2);

-- Сеанс A:
BEGIN ISOLATION LEVEL REPEATABLE READ;
-- REPEATABLE READ: snapshot transaction başında bir kez alınır
-- sonraki tüm okumalar aynı veri durumunu görür
SELECT id, service_id FROM works WHERE id = 9901;
-- ilk okuma: service_id = 1

-- Сеанс B:
-- BEGIN ISOLATION LEVEL REPEATABLE READ;
-- UPDATE works SET service_id = 3 WHERE id = 9901;
-- COMMIT;

-- Сеанс A - второй SELECT:
SELECT id, service_id FROM works WHERE id = 9901;
-- ANOMALİ YOK: service_id hâlâ 1, snapshot transaction başında kilitlendi
-- REPEATABLE READ aynı satırın aynı transaction içinde hep aynı okunmasını garanti eder
COMMIT;


-- Тест 2.2 - Фантом на REPEATABLE READ
-- Ожидаем: аномалии НЕТ (PostgreSQL предотвращает через MVCC)

DELETE FROM works WHERE id IN (9901, 9902);
INSERT INTO works (id, date_work, master_id, car_id, service_id)
VALUES (9901, CURRENT_DATE, 1, 1, 1), (9902, CURRENT_DATE, 2, 2, 2);

-- Сеанс A:
BEGIN ISOLATION LEVEL REPEATABLE READ;
SELECT COUNT(*) AS cnt FROM works WHERE master_id = 1;

-- Сеанс B:
-- BEGIN ISOLATION LEVEL REPEATABLE READ;
-- INSERT INTO works (date_work, master_id, car_id, service_id)
-- VALUES (CURRENT_DATE, 1, 1, 1);
-- COMMIT;

-- Сеанс A - второй COUNT:
SELECT COUNT(*) AS cnt FROM works WHERE master_id = 1;
-- HAYALET YOK: cnt aynı kalır
-- PostgreSQL MVCC (Multi-Version Concurrency Control) kullanır:
-- her transaction kendi veri versiyonuyla çalışır
-- başka transaction'ın eklediği yeni satırlar bizim snapshot'ta görünmez
COMMIT;


-- Тест 2.3 - Аномалия сериализации на REPEATABLE READ
-- Ожидаем: АНОМАЛИЯ ЕСТЬ
-- Исходное: 9901.service_id=1, 9902.service_id=2
-- При последовательном: оба станут 2
-- При параллельном RR: получится своп (9901=2, 9902=1)

-- Шаг 1: последовательное выполнение (эталон)
DELETE FROM works WHERE id IN (9901, 9902);
INSERT INTO works (id, date_work, master_id, car_id, service_id)
VALUES (9901, CURRENT_DATE, 1, 1, 1), (9902, CURRENT_DATE, 2, 2, 2);

BEGIN;
-- BEGIN izolasyon seviyesi belirtilmezse varsayılan READ COMMITTED kullanılır
UPDATE works SET service_id = (SELECT service_id FROM works WHERE id = 9902) WHERE id = 9901;
-- alt sorgu: önce 9902'nin service_id'sini okur (=2), sonra 9901'e yazar
COMMIT;
BEGIN;
UPDATE works SET service_id = (SELECT service_id FROM works WHERE id = 9901) WHERE id = 9902;
-- şimdi 9901 = 2 oldu, dolayısıyla 9902 da 2 olur
COMMIT;
SELECT id, service_id FROM works WHERE id IN (9901, 9902) ORDER BY id;
-- sonuç: 9901=2, 9902=2 — sıralı çalışmanın doğru sonucu

-- Шаг 2: параллельное выполнение (воспроизводим аномалию)
DELETE FROM works WHERE id IN (9901, 9902);
INSERT INTO works (id, date_work, master_id, car_id, service_id)
VALUES (9901, CURRENT_DATE, 1, 1, 1), (9902, CURRENT_DATE, 2, 2, 2);

-- Сеанс A:
BEGIN ISOLATION LEVEL REPEATABLE READ;
UPDATE works SET service_id = (SELECT service_id FROM works WHERE id = 9902) WHERE id = 9901;
-- Seans A snapshot'ı başta aldı: 9902.service_id = 2
-- dolayısıyla 9901.service_id = 2 yazar

-- Сеанс B (параллельно):
-- BEGIN ISOLATION LEVEL REPEATABLE READ;
-- UPDATE works SET service_id = (SELECT service_id FROM works WHERE id = 9901) WHERE id = 9902;
-- Seans B de kendi snapshot'ını aldı: 9901.service_id = 1 (A'nın değişikliğinden önce!)
-- dolayısıyla 9902.service_id = 1 yazar
-- COMMIT;

-- Сеанс A:
COMMIT;

SELECT id, service_id FROM works WHERE id IN (9901, 9902) ORDER BY id;
-- sonuç: 9901=2, 9902=1 (swap!)
-- ANOMALİ: sıralı sonuçtan (9901=2, 9902=2) farklı


-- =============================================
-- ЧАСТЬ 3: SERIALIZABLE
-- =============================================

-- Тест 3.1 - Аномалия сериализации на SERIALIZABLE
-- Ожидаем: одна транзакция откатится с ошибкой

DELETE FROM works WHERE id IN (9901, 9902);
INSERT INTO works (id, date_work, master_id, car_id, service_id)
VALUES (9901, CURRENT_DATE, 1, 1, 1), (9902, CURRENT_DATE, 2, 2, 2);

-- Сеанс A:
BEGIN ISOLATION LEVEL SERIALIZABLE;
-- SERIALIZABLE: en katı izolasyon seviyesi
-- PostgreSQL transactionlar arası bağımlılıkları takip eder (SSI algoritması)
-- okuma/yazma çakışması tespit edilirse bir transaction otomatik geri alınır
UPDATE works SET service_id = (SELECT service_id FROM works WHERE id = 9902) WHERE id = 9901;

-- Сеанс B (параллельно):
-- BEGIN ISOLATION LEVEL SERIALIZABLE;
-- UPDATE works SET service_id = (SELECT service_id FROM works WHERE id = 9901) WHERE id = 9902;
-- COMMIT;
-- HATA: could not serialize access due to read/write dependencies among transactions
-- HINT: The transaction might succeed if retried.
-- PostgreSQL döngüsel bağımlılık tespit etti: A, 9902'yi okuyor; B, 9901'i okuyor
-- ikisi de aynı satırlara yazıyor — bu sıralı çalışmayla uyuşmuyor, B geri alındı

-- Сеанс A:
COMMIT;
-- Seans A başarıyla tamamlandı, Seans B hata alıp tekrar denemelidir

SELECT id, service_id FROM works WHERE id IN (9901, 9902) ORDER BY id;
-- sonuç sıralı çalışmayla aynı — anomali yok
