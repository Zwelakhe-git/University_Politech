# Институт информационных технологий и управления
## «Высшая школа программной инженерии»

&nbsp;

&nbsp;

&nbsp;

# ЛАБОРАТОРНАЯ РАБОТА №1.4 и №2.1

### Контроль целостности данных. Управление доступом.

### по дисциплине «Базы данных»

&nbsp;

&nbsp;

&nbsp;

&nbsp;

Выполнил

Студент &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Гюнеш М.М

гр.5130904/30103

Руководитель &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Юркин В А

&nbsp;

&nbsp;

&nbsp;

### Санкт-Петербург
### 2025

---

# Содержание

- [Задание 1.4 — Контроль целостности данных](#задание-14)
  - [Уровни изоляции и аномалии](#уровни-изоляции)
  - [READ COMMITTED — проверка аномалий](#read-committed)
  - [REPEATABLE READ — проверка аномалий](#repeatable-read)
  - [SERIALIZABLE — проверка аномалий](#serializable)
  - [Выводы по заданию 1.4](#выводы-14)
- [Задание 2.1 — Управление доступом](#задание-21)
  - [Создание пользователя и права доступа](#пользователь)
  - [Представления](#представления)
  - [Вставка в многотабличное представление](#вставка)
  - [Роль и проверка прав](#роль)
  - [Макрокоманда \dp](#dp)
  - [Выводы по заданию 2.1](#выводы-21)

---

# Задание 1.4 — Контроль целостности данных <a name="задание-14"></a>

## Уровни изоляции и аномалии <a name="уровни-изоляции"></a>

**Уровни изоляции** — правила, которые определяют, как параллельные транзакции видят изменения, внесённые другими транзакциями.

| Уровень изоляции | Грязное чтение | Потерянное изменение | Неповт. чтение | Фантом | Аномалия сериализации |
|---|---|---|---|---|---|
| READ UNCOMMITTED | да | нет | да | да | да |
| READ COMMITTED | нет | нет | да | да | да |
| REPEATABLE READ | нет | нет | нет | нет* | да |
| SERIALIZABLE | нет | нет | нет | нет | нет |

> *PostgreSQL предотвращает фантомы на REPEATABLE READ через MVCC, хотя стандарт SQL этого не требует.

**Аномалии:**

- **Грязное чтение** — транзакция читает незафиксированные изменения другой транзакции. В PostgreSQL не возникает даже на READ UNCOMMITTED.
- **Потерянное изменение** — два параллельных инкремента: один из них «теряется». PostgreSQL предотвращает через row-level lock.
- **Неповторяющееся чтение** — один и тот же запрос внутри транзакции возвращает разные значения строки.
- **Фантомное чтение** — один и тот же запрос внутри транзакции возвращает разное количество строк.
- **Аномалия сериализации** — результат параллельного выполнения не совпадает с результатом последовательного.

Для тестов используются строки таблицы **works** с фиксированными id:

```sql
DELETE FROM works WHERE id IN (9901, 9902);
INSERT INTO works (id, date_work, master_id, car_id, service_id)
VALUES (9901, CURRENT_DATE, 1, 1, 1),
       (9902, CURRENT_DATE, 2, 2, 2);
```

Начальное состояние: `works id=9901 (service_id=1)`, `works id=9902 (service_id=2)`

---

## READ COMMITTED — проверка аномалий <a name="read-committed"></a>

### 1.1 Грязное чтение (Dirty Read) — ожидаем: аномалии НЕТ

| Транзакция A (Сеанс 1) | Транзакция B (Сеанс 2) | Результат |
|---|---|---|
| `BEGIN ISOLATION LEVEL READ COMMITTED;` | | |
| `UPDATE works SET service_id = 3 WHERE id = 9901;` | | строка заблокирована, не зафиксировано |
| | `BEGIN ISOLATION LEVEL READ COMMITTED;` | |
| | `SELECT id, service_id FROM works WHERE id = 9901;` | **service_id = 1** (не 3!) |
| `ROLLBACK;` | | |
| | `SELECT id, service_id FROM works WHERE id = 9901;` | **service_id = 1** |
| | `COMMIT;` | |

**Вывод:** Грязного чтения нет. Сеанс B видит только зафиксированные данные (service_id = 1), а не незафиксированное изменение сеанса A (service_id = 3).

---

### 1.2 Потерянное изменение (Lost Update) — ожидаем: аномалии НЕТ

Начальное значение: `services id=1, cost_our = 1500`

| Транзакция A (Сеанс 1) | Транзакция B (Сеанс 2) | Результат |
|---|---|---|
| `BEGIN ISOLATION LEVEL READ COMMITTED;` | | |
| `UPDATE services SET cost_our = cost_our + 500 WHERE id = 1;` | | строка заблокирована (row-level lock) |
| | `BEGIN ISOLATION LEVEL READ COMMITTED;` | |
| | `UPDATE services SET cost_our = cost_our + 1000 WHERE id = 1;` | **ОЖИДАНИЕ** блокировки |
| `COMMIT;` — cost_our = 2000 | | блокировка снята |
| | разблокировался, читает 2000 | |
| | `COMMIT;` — cost_our = 3000 | |

```
-- Итоговая проверка:
SELECT cost_our FROM services WHERE id = 1;
 cost_our
----------
     3000
```

**Вывод:** Потерянных изменений нет. PostgreSQL блокирует строку при UPDATE, второй инкремент применяется к уже зафиксированному значению. Оба инкремента сохранены: 1500 + 500 + 1000 = 3000.

---

### 1.3 Неповторяющееся чтение (Non-Repeatable Read) — ожидаем: АНОМАЛИЯ ЕСТЬ

| Транзакция A (Сеанс 1) | Транзакция B (Сеанс 2) | Результат |
|---|---|---|
| `BEGIN ISOLATION LEVEL READ COMMITTED;` | | |
| `SELECT id, service_id FROM works WHERE id = 9901;` | | **service_id = 1** |
| | `BEGIN ISOLATION LEVEL READ COMMITTED;` | |
| | `UPDATE works SET service_id = 3 WHERE id = 9901;` | |
| | `COMMIT;` | изменение зафиксировано |
| `SELECT id, service_id FROM works WHERE id = 9901;` | | **service_id = 3 (!)** |
| `COMMIT;` | | |

**Вывод:** Аномалия возникает. На READ COMMITTED снимок данных берётся заново для каждого запроса, поэтому второе чтение показывает уже зафиксированное изменение другой транзакции.

---

### 1.4 Фантомное чтение (Phantom Read) — ожидаем: АНОМАЛИЯ ЕСТЬ

| Транзакция A (Сеанс 1) | Транзакция B (Сеанс 2) | Результат |
|---|---|---|
| `BEGIN ISOLATION LEVEL READ COMMITTED;` | | |
| `SELECT COUNT(*) AS cnt FROM works WHERE master_id = 1;` | | **cnt = 3** |
| | `BEGIN ISOLATION LEVEL READ COMMITTED;` | |
| | `INSERT INTO works (date_work, master_id, car_id, service_id) VALUES (CURRENT_DATE, 1, 1, 1);` | |
| | `COMMIT;` | новая строка зафиксирована |
| `SELECT COUNT(*) AS cnt FROM works WHERE master_id = 1;` | | **cnt = 4 (!)** |
| `COMMIT;` | | |

**Вывод:** Аномалия возникает. На READ COMMITTED каждый запрос видит актуальные данные, включая новые строки, вставленные другими транзакциями.

---

## REPEATABLE READ — проверка аномалий <a name="repeatable-read"></a>

### 2.1 Неповторяющееся чтение на REPEATABLE READ — ожидаем: аномалии НЕТ

| Транзакция A (Сеанс 1) | Транзакция B (Сеанс 2) | Результат |
|---|---|---|
| `BEGIN ISOLATION LEVEL REPEATABLE READ;` | | |
| `SELECT id, service_id FROM works WHERE id = 9901;` | | **service_id = 1** |
| | `BEGIN ISOLATION LEVEL REPEATABLE READ;` | |
| | `UPDATE works SET service_id = 3 WHERE id = 9901;` | |
| | `COMMIT;` | изменение зафиксировано |
| `SELECT id, service_id FROM works WHERE id = 9901;` | | **service_id = 1** (не изменилось!) |
| `COMMIT;` | | |

**Вывод:** Аномалии нет. На REPEATABLE READ снимок данных берётся один раз в начале транзакции. Все последующие чтения используют тот же снимок.

---

### 2.2 Фантомное чтение на REPEATABLE READ — ожидаем: аномалии НЕТ

| Транзакция A (Сеанс 1) | Транзакция B (Сеанс 2) | Результат |
|---|---|---|
| `BEGIN ISOLATION LEVEL REPEATABLE READ;` | | |
| `SELECT COUNT(*) AS cnt FROM works WHERE master_id = 1;` | | **cnt = 3** |
| | `BEGIN ISOLATION LEVEL REPEATABLE READ;` | |
| | `INSERT INTO works (date_work, master_id, car_id, service_id) VALUES (CURRENT_DATE, 1, 1, 1);` | |
| | `COMMIT;` | новая строка зафиксирована |
| `SELECT COUNT(*) AS cnt FROM works WHERE master_id = 1;` | | **cnt = 3** (не изменилось!) |
| `COMMIT;` | | |

**Вывод:** Фантомов нет. PostgreSQL использует MVCC (Multi-Version Concurrency Control) — каждая транзакция работает со своей версией данных. Новые строки, вставленные другой транзакцией, невидимы в нашем снимке.

---

### 2.3 Аномалия сериализации на REPEATABLE READ — ожидаем: АНОМАЛИЯ ЕСТЬ

Исходное состояние: `9901.service_id = 1`, `9902.service_id = 2`

**Шаг 1: Последовательное выполнение (эталон)**

```sql
BEGIN;
UPDATE works SET service_id = (SELECT service_id FROM works WHERE id = 9902) WHERE id = 9901;
COMMIT;
BEGIN;
UPDATE works SET service_id = (SELECT service_id FROM works WHERE id = 9901) WHERE id = 9902;
COMMIT;

SELECT id, service_id FROM works WHERE id IN (9901, 9902) ORDER BY id;
```

```
  id  | service_id
------+------------
 9901 |          2
 9902 |          2
```

Состояние 1 (последовательное): `9901=2, 9902=2`

**Шаг 2: Параллельное выполнение**

| Транзакция A (Сеанс 1) | Транзакция B (Сеанс 2) | Результат |
|---|---|---|
| `BEGIN ISOLATION LEVEL REPEATABLE READ;` | `BEGIN ISOLATION LEVEL REPEATABLE READ;` | снимок: 9901=1, 9902=2 |
| `UPDATE works SET service_id=(SELECT service_id FROM works WHERE id=9902) WHERE id=9901;` | | A видит 9902=2, пишет 9901=2 |
| | `UPDATE works SET service_id=(SELECT service_id FROM works WHERE id=9901) WHERE id=9902;` | B видит 9901=1 (снимок!), пишет 9902=1 |
| `COMMIT;` | | успешно |
| | `COMMIT;` | успешно |

```sql
SELECT id, service_id FROM works WHERE id IN (9901, 9902) ORDER BY id;
```

```
  id  | service_id
------+------------
 9901 |          2
 9902 |          1
```

Состояние 2 (параллельное): `9901=2, 9902=1` — СВОП!

**Вывод:** Аномалия сериализации возникает. Состояние 1 (9901=2, 9902=2) ≠ Состояние 2 (9901=2, 9902=1). REPEATABLE READ гарантирует консистентность внутри одной транзакции, но не отслеживает зависимости между параллельными транзакциями.

---

## SERIALIZABLE — проверка аномалий <a name="serializable"></a>

### 3.1 Аномалия сериализации на SERIALIZABLE — ожидаем: откат одной транзакции

| Транзакция A (Сеанс 1) | Транзакция B (Сеанс 2) | Результат |
|---|---|---|
| `BEGIN ISOLATION LEVEL SERIALIZABLE;` | `BEGIN ISOLATION LEVEL SERIALIZABLE;` | |
| `UPDATE works SET service_id=(SELECT service_id FROM works WHERE id=9902) WHERE id=9901;` | | |
| | `UPDATE works SET service_id=(SELECT service_id FROM works WHERE id=9901) WHERE id=9902;` | |
| `COMMIT;` | | **успешно** |
| | `COMMIT;` | **ОШИБКА:** could not serialize access due to read/write dependencies among transactions |

```
ОШИБКА:  не удалось сериализовать доступ из-за зависимостей чтения/записи между транзакциями
ПОДРОБНОСТИ: Reason code: Canceled on identification as a pivot, during commit attempt.
ПОДСКАЗКА:  Транзакция может завершиться успешно при следующей попытке.
```

```sql
SELECT id, service_id FROM works WHERE id IN (9901, 9902) ORDER BY id;
```

```
  id  | service_id
------+------------
 9901 |          2
 9902 |          2
```

**Вывод:** Аномалии нет. PostgreSQL использует SSI (Serializable Snapshot Isolation) — отслеживает зависимости чтения/записи между транзакциями. При обнаружении циклической зависимости одна транзакция автоматически откатывается. Результат соответствует последовательному выполнению.

---

## Выводы по заданию 1.4 <a name="выводы-14"></a>

В ходе выполнения задания были проверены все основные аномалии транзакций на трёх уровнях изоляции PostgreSQL.

Итоговая таблица наблюдений:

| Аномалия | READ COMMITTED | REPEATABLE READ | SERIALIZABLE |
|---|---|---|---|
| Грязное чтение | Нет | Нет | Нет |
| Потерянное изменение | Нет | Нет | Нет |
| Неповторяющееся чтение | **Есть** | Нет | Нет |
| Фантомное чтение | **Есть** | Нет | Нет |
| Аномалия сериализации | **Есть** | **Есть** | Нет (откат) |

Особенности PostgreSQL:
- Грязного чтения нет даже на READ UNCOMMITTED, так как PostgreSQL не реализует этот уровень отдельно.
- REPEATABLE READ предотвращает фантомы через MVCC, что отличает PostgreSQL от стандарта SQL/92.
- SERIALIZABLE использует алгоритм SSI (а не блокировки), что обеспечивает высокую параллельность при полной изоляции.

---

# Задание 2.1 — Управление доступом <a name="задание-21"></a>

## Создание пользователя и права доступа к таблицам <a name="пользователь"></a>

### Создание пользователя test

```sql
CREATE USER test WITH PASSWORD 'test123';
GRANT CONNECT ON DATABASE labone TO test;
GRANT USAGE ON SCHEMA public TO test;
```

### Права на таблицы

```sql
-- works: SELECT, INSERT, UPDATE (без DELETE)
GRANT SELECT, INSERT, UPDATE ON TABLE works TO test;
GRANT USAGE, SELECT ON SEQUENCE works_id_seq TO test;

-- cars: SELECT везде, UPDATE только по столбцу color
GRANT SELECT ON TABLE cars TO test;
GRANT UPDATE (color) ON TABLE cars TO test;

-- services: только SELECT (справочник)
GRANT SELECT ON TABLE services TO test;

-- masters: SELECT (нужен для представлений)
GRANT SELECT ON TABLE masters TO test;
```

---

## Представления <a name="представления"></a>

### Однотабличное представление — работы за текущий год

```sql
CREATE VIEW v_works_current_year AS
SELECT id, date_work, master_id, car_id, service_id
FROM works
WHERE EXTRACT(YEAR FROM date_work) = EXTRACT(YEAR FROM CURRENT_DATE);
```

```
SELECT * FROM v_works_current_year LIMIT 3;
  id  | date_work  | master_id | car_id | service_id
------+------------+-----------+--------+------------
    5 | 2025-05-12 |         5 |      5 |          5
    6 | 2025-06-08 |         1 |      6 |          6
    7 | 2025-07-25 |         2 |      7 |          7
(3 строки)
```

### Однотабличное представление — только иностранные автомобили (WITH CHECK OPTION)

```sql
CREATE VIEW v_foreign_cars AS
SELECT id, num, color, mark, is_foreign
FROM cars
WHERE is_foreign = TRUE
WITH CHECK OPTION;
```

`WITH CHECK OPTION` гарантирует, что через это представление нельзя вставить или изменить строку так, чтобы она перестала удовлетворять условию `is_foreign = TRUE`.

```
SELECT * FROM v_foreign_cars LIMIT 3;
 id |  num  |    color    |       mark       | is_foreign
----+-------+-------------+------------------+------------
  2 |  5678 | Синий       | Kia Rio          | t
  3 |  9012 | Черный      | Hyundai Solaris  | t
  5 |  7890 | Зеленый     | Toyota Camry     | t
(3 строки)
```

### Многотабличное представление — полная информация о работах

```sql
CREATE VIEW v_works_details AS
SELECT
    w.id AS work_id,
    w.date_work,
    m.name AS master_name,
    c.mark AS car_mark,
    c.num AS car_num,
    c.color AS car_color,
    c.is_foreign,
    s.name AS service_name,
    CASE
        WHEN c.is_foreign THEN s.cost_foreign
        ELSE s.cost_our
    END AS cost
FROM works w
JOIN masters m ON w.master_id = m.id
JOIN cars c ON w.car_id = c.id
JOIN services s ON w.service_id = s.id;
```

```
SELECT * FROM v_works_details LIMIT 3;
 work_id | date_work  |  master_name   |    car_mark     | car_num | car_color | is_foreign | service_name            | cost
---------+------------+----------------+-----------------+---------+-----------+------------+-------------------------+------
       1 | 2025-03-15 | Иванов Иван    | Lada Granta     |    1234 | Красный   | f          | Замена масла            | 1500
       2 | 2025-02-10 | Мария Сидорова | Kia Rio         |    5678 | Синий     | t          | Замена тормозных колодок| 6000
       3 | 2025-01-05 | Алексей Козлов | Hyundai Solaris |    9012 | Черный    | t          | Развал-схождение        | 4000
(3 строки)
```

### Многотабличное представление — статистика по мастерам

```sql
CREATE VIEW v_master_stats AS
SELECT
    m.id AS master_id,
    m.name AS master_name,
    COUNT(w.id) AS total_works,
    SUM(CASE WHEN c.is_foreign THEN s.cost_foreign ELSE s.cost_our END) AS total_revenue
FROM masters m
LEFT JOIN works w ON w.master_id = m.id
LEFT JOIN cars c ON w.car_id = c.id
LEFT JOIN services s ON w.service_id = s.id
GROUP BY m.id, m.name
ORDER BY total_revenue DESC NULLS LAST;
```

```
SELECT * FROM v_master_stats;
 master_id |    master_name     | total_works | total_revenue
-----------+--------------------+-------------+---------------
         1 | Иванов Иван        |           5 |         34500
         3 | Алексей Козлов     |           4 |         28000
         5 | Дмитрий Волков     |           4 |         25000
         2 | Мария Сидорова     |           4 |         23500
         4 | Екатерина Новикова |           3 |         18000
(5 строк)
```

### Материализованное представление — выручка по услугам

```sql
CREATE MATERIALIZED VIEW mv_service_revenue AS
SELECT
    s.id AS service_id,
    s.name AS service_name,
    s.cost_our,
    s.cost_foreign,
    COUNT(w.id) AS times_used,
    SUM(CASE WHEN c.is_foreign THEN s.cost_foreign ELSE s.cost_our END) AS total_revenue
FROM services s
LEFT JOIN works w ON w.service_id = s.id
LEFT JOIN cars c ON w.car_id = c.id
GROUP BY s.id, s.name, s.cost_our, s.cost_foreign
ORDER BY total_revenue DESC NULLS LAST;
```

Материализованное представление сохраняет результаты запроса физически на диск. В отличие от обычного представления, данные не пересчитываются при каждом обращении, что ускоряет работу с большими объёмами данных. При изменении базовых данных необходимо выполнить:

```sql
REFRESH MATERIALIZED VIEW mv_service_revenue;
```

---

## Вставка в многотабличное представление <a name="вставка"></a>

Прямая вставка в многотабличное представление невозможна, так как PostgreSQL не может автоматически определить, в какие таблицы распределять данные. Для решения используется триггер `INSTEAD OF INSERT`.

```sql
CREATE OR REPLACE FUNCTION fn_insert_works_details()
RETURNS TRIGGER
LANGUAGE plpgsql AS $$
DECLARE
    v_master_id  INTEGER;
    v_car_id     INTEGER;
    v_service_id INTEGER;
BEGIN
    SELECT id INTO v_master_id FROM masters WHERE name = NEW.master_name;
    IF v_master_id IS NULL THEN
        RAISE EXCEPTION 'Мастер "%" не найден', NEW.master_name;
    END IF;

    SELECT id INTO v_car_id FROM cars WHERE mark = NEW.car_mark AND num = NEW.car_num;
    IF v_car_id IS NULL THEN
        RAISE EXCEPTION 'Автомобиль "%" №% не найден', NEW.car_mark, NEW.car_num;
    END IF;

    SELECT id INTO v_service_id FROM services WHERE name = NEW.service_name;
    IF v_service_id IS NULL THEN
        RAISE EXCEPTION 'Услуга "%" не найдена', NEW.service_name;
    END IF;

    INSERT INTO works (date_work, master_id, car_id, service_id)
    VALUES (COALESCE(NEW.date_work, CURRENT_DATE), v_master_id, v_car_id, v_service_id);

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_insert_works_details
INSTEAD OF INSERT ON v_works_details
FOR EACH ROW EXECUTE FUNCTION fn_insert_works_details();
```

**Проверка вставки:**

```sql
INSERT INTO v_works_details (date_work, master_name, car_mark, car_num, service_name)
VALUES (CURRENT_DATE, 'Иванов Иван', 'Lada Vesta', '3456', 'Замена масла');
```

```
INSERT 0 1
```

```sql
SELECT * FROM v_works_details ORDER BY work_id DESC LIMIT 1;
```

```
 work_id | date_work  | master_name | car_mark   | car_num | car_color | is_foreign | service_name | cost
---------+------------+-------------+------------+---------+-----------+------------+--------------+------
      21 | 2026-03-16 | Иванов Иван | Lada Vesta |    3456 | Белый     | f          | Замена масла | 1500
(1 строка)
```

---

## Роль и проверка прав <a name="роль"></a>

### Создание роли role_car_manager

```sql
CREATE ROLE role_car_manager;
GRANT SELECT ON TABLE v_foreign_cars TO role_car_manager;
GRANT UPDATE (color, mark) ON TABLE v_foreign_cars TO role_car_manager;
GRANT SELECT ON TABLE v_works_details TO role_car_manager;
GRANT role_car_manager TO test;
```

### Права на представления для пользователя test

```sql
GRANT SELECT ON TABLE v_works_current_year TO test;
GRANT SELECT ON TABLE v_works_details TO test;
GRANT SELECT ON TABLE v_master_stats TO test;
GRANT SELECT ON TABLE mv_service_revenue TO test;
GRANT INSERT ON TABLE v_works_details TO test;
GRANT USAGE, SELECT ON SEQUENCE works_id_seq TO test;
```

### Проверка прав от имени пользователя test

**Разрешённые операции:**

```sql
-- SELECT на таблицы
SELECT * FROM works LIMIT 1;           -- OK
SELECT * FROM cars LIMIT 1;            -- OK
SELECT * FROM services LIMIT 1;        -- OK

-- INSERT в works
INSERT INTO works (date_work, master_id, car_id, service_id)
VALUES (CURRENT_DATE, 1, 1, 1);        -- OK

-- UPDATE только столбца color в cars
UPDATE cars SET color = 'Белый' WHERE id = 1;   -- OK

-- INSERT через представление (INSTEAD OF триггер)
INSERT INTO v_works_details (date_work, master_name, car_mark, car_num, service_name)
VALUES (CURRENT_DATE, 'Иванов Иван', 'Lada Vesta', '3456', 'Замена масла');  -- OK
```

**Запрещённые операции (возвращают ERROR):**

```sql
-- UPDATE другого столбца cars
UPDATE cars SET num = '9999' WHERE id = 1;
-- ОШИБКА:  нет права на UPDATE на столбец "num" в отношении "cars"

-- UPDATE таблицы services
UPDATE services SET cost_our = 0 WHERE id = 1;
-- ОШИБКА:  нет права на UPDATE на отношение "services"

-- DELETE из works
DELETE FROM works WHERE id = 1;
-- ОШИБКА:  нет права на DELETE на отношение "works"
```

---

## Макрокоманда \dp <a name="dp"></a>

Для просмотра флагов прав доступа в psql используется команда `\dp`. На Windows для корректного отображения кириллицы необходимо сначала выполнить `\! chcp 1251`.

```
labone=# \dp works
                                  Права доступа
 Схема  |  Имя  |   Тип   |         Права доступа          | Права для столбцов | Политики
--------+-------+---------+--------------------------------+--------------------+----------
 public | works | таблица | postgres=arwdDxtm/postgres     +|                    |
        |       |         | test=arw/postgres               |                    |
(1 строка)

labone=# \dp cars
                                  Права доступа
 Схема  | Имя  |   Тип   |         Права доступа          |  Права для столбцов   | Политики
--------+------+---------+--------------------------------+-----------------------+----------
 public | cars | таблица | postgres=arwdDxtm/postgres     +| color:               +|
        |      |         | test=r/postgres                +|   test=w/postgres     |
        |      |         | role_car_manager=r/postgres    +|                       |
(1 строка)

labone=# \dp services
                                  Права доступа
 Схема  |   Имя    |   Тип   |         Права доступа         | Права для столбцов | Политики
--------+----------+---------+-------------------------------+--------------------+----------
 public | services | таблица | postgres=arwdDxtm/postgres    +|                    |
        |          |         | test=r/postgres                |                    |
(1 строка)
```

**Расшифровка флагов привилегий:**

| Флаг | Привилегия |
|---|---|
| r | SELECT (read) |
| a | INSERT (append) |
| w | UPDATE (write) |
| d | DELETE |
| D | TRUNCATE |
| x | REFERENCES |
| t | TRIGGER |
| m | MAINTAIN |

Пример: `test=arw/postgres` означает, что пользователю `test` выданы права INSERT(a) + SELECT(r) + UPDATE(w), и выданы суперпользователем `postgres`.

---

## Выводы по заданию 2.1 <a name="выводы-21"></a>

В ходе выполнения задания была реализована система управления доступом в базе данных `labone`. Создан пользователь `test` с различными уровнями прав на разные таблицы:

- **works** — полный доступ (SELECT, INSERT, UPDATE), но без DELETE
- **cars** — SELECT на всё, UPDATE только на столбец `color`
- **services** — только SELECT (справочная таблица, изменять нельзя)

Созданы представления разных типов: однотабличные (с фильтрацией и `WITH CHECK OPTION`), многотабличные (с JOIN), материализованное представление (с кешированием).

Для вставки в многотабличное представление `v_works_details` реализован триггер `INSTEAD OF INSERT`, который автоматически находит id мастера, автомобиля и услуги по их именам и выполняет вставку в базовую таблицу `works`.

Создана роль `role_car_manager` с правом обновления столбцов `color` и `mark` через представление `v_foreign_cars`. Роль назначена пользователю `test`.

Все права проверены: разрешённые операции выполняются успешно, запрещённые возвращают соответствующие ошибки.
