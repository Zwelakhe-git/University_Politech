-- Задание 2.1 - Управление доступом
-- БД: labone (Автосервис)
-- Выполнять от суперпользователя postgres


-- =============================================
-- 1. Создание пользователя test
-- =============================================

DO $$
BEGIN
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'test') THEN
        EXECUTE 'DROP OWNED BY test CASCADE';
        EXECUTE 'DROP USER test';
    END IF;
END
$$;
-- DO $$ ... $$: isim verilmeksizin çalıştırılan anonim PL/pgSQL bloğu
-- IF EXISTS: silmeden önce var mı diye kontrol eder, yoksa hata vermez
-- pg_roles: PostgreSQL'in tüm kullanıcı ve rolleri tutan sistem tablosu
-- DROP OWNED BY test CASCADE: test kullanıcısına ait tüm nesneleri siler
-- CASCADE: bağımlı nesneleri de (haklar, view vb.) birlikte siler
-- EXECUTE: string olarak verilen SQL'i dinamik biçimde çalıştırır

CREATE USER test WITH PASSWORD 'test123';
-- CREATE USER: veritabanı kullanıcısı oluşturur
-- WITH PASSWORD: giriş için şifre belirler
-- kullanıcı = LOGIN hakkı olan bir role'dür

GRANT CONNECT ON DATABASE labone TO test;
-- GRANT: ayrıcalık verir
-- CONNECT ON DATABASE: veritabanına bağlanma hakkı
-- bu olmadan kullanıcı veritabanına hiç giremez

GRANT USAGE ON SCHEMA public TO test;
-- USAGE ON SCHEMA: şema içindeki nesneleri (tablo, view vb.) görme hakkı
-- bu olmadan tablo haklarına sahip olsa bile nesneleri göremez


-- =============================================
-- 2. Права на таблицы
-- =============================================

GRANT SELECT, INSERT, UPDATE ON TABLE works TO test;
-- SELECT: satır okuma hakkı
-- INSERT: satır ekleme hakkı
-- UPDATE: satır güncelleme hakkı
-- DELETE kasıtlı verilmedi — test kullanıcısı works tablosundan kayıt silemez

GRANT USAGE, SELECT ON SEQUENCE works_id_seq TO test;
-- works_id_seq: id sütunu için otomatik değer üreten sequence (SERIAL)
-- USAGE: INSERT sırasında nextval() çağırma hakkı — yeni id almak için şart
-- SELECT: currval() ile mevcut değeri okuma hakkı
-- bu olmadan works tablosuna INSERT yapılırken hata verir

GRANT SELECT ON TABLE cars TO test;
-- sadece okuma — araç verilerini görebilir ama değiştiremez

GRANT UPDATE (color) ON TABLE cars TO test;
-- sütun seviyesinde UPDATE: sadece color değiştirilebilir
-- num, mark, is_foreign sütunlarına dokunmaya çalışırsa permission denied hatası alır
-- buna column-level privilege denir

GRANT SELECT ON TABLE services TO test;
-- services: fiyat listesi tablosu, sadece okunabilir

GRANT SELECT ON TABLE masters TO test;
-- masters tablosu view'lardaki JOIN'ler için gerekli


-- =============================================
-- 3. Представления (Views)
-- =============================================

-- 3.1 Однотабличное - работы за текущий год
DROP VIEW IF EXISTS v_works_current_year CASCADE;
-- DROP VIEW IF EXISTS: zaten varsa siler, yoksa hata vermez
-- CASCADE: bağımlı nesneleri de birlikte siler

CREATE VIEW v_works_current_year AS
SELECT id, date_work, master_id, car_id, service_id
FROM works
WHERE EXTRACT(YEAR FROM date_work) = EXTRACT(YEAR FROM CURRENT_DATE);
-- CREATE VIEW: SELECT sorgusuna dayanan sanal tablo oluşturur
-- fiziksel veri saklamaz, her erişimde sorgu çalışır
-- EXTRACT(YEAR FROM date_work): tarih değerinden yıl bilgisini çıkarır
-- CURRENT_DATE: her gün otomatik güncellenen bugünün tarihi

SELECT * FROM v_works_current_year LIMIT 5;
-- LIMIT 5: en fazla 5 satır döndürür, kontrol amaçlı kullanılır


-- 3.2 Однотабличное - только иностранные авто
DROP VIEW IF EXISTS v_foreign_cars CASCADE;

CREATE VIEW v_foreign_cars AS
SELECT id, num, color, mark, is_foreign
FROM cars
WHERE is_foreign = TRUE
WITH CHECK OPTION;
-- WHERE is_foreign = TRUE: sadece yabancı araçları filtreler
-- WITH CHECK OPTION: bu view üzerinden yapılan INSERT/UPDATE kontrol edilir
--   eğer eklenmek istenen satır WHERE koşulunu sağlamıyorsa işlem reddedilir
--   yani yerli araç bu view üzerinden eklenemez

SELECT * FROM v_foreign_cars LIMIT 5;


-- 3.3 Многотабличное - полная информация о работах
DROP VIEW IF EXISTS v_works_details CASCADE;

CREATE VIEW v_works_details AS
SELECT
    w.id AS work_id,
    w.date_work,
    m.name AS master_name,
    c.mark AS car_mark,
    c.num AS car_num,
    c.color AS car_color,
    c.is_foreign,
    s.name AS service_name,
    CASE
        WHEN c.is_foreign THEN s.cost_foreign
        ELSE s.cost_our
    END AS cost
FROM works w
JOIN masters m ON w.master_id = m.id
JOIN cars c ON w.car_id = c.id
JOIN services s ON w.service_id = s.id;
-- JOIN (INNER JOIN): iki tabloyu ON koşuluna göre birleştirir
--   her iki tarafta eşleşme olan satırlar döner
-- w.master_id = m.id: foreign key ilişkisiyle bağlanır
-- AS work_id, AS master_name: sütun takma adları, okunabilirlik için
-- CASE WHEN ... THEN ... ELSE ... END: koşullu ifade
--   araç yabancıysa yabancı fiyatı, yerli ise yerli fiyat alınır

SELECT * FROM v_works_details LIMIT 5;


-- 3.4 Многотабличное - статистика по мастерам
DROP VIEW IF EXISTS v_master_stats CASCADE;

CREATE VIEW v_master_stats AS
SELECT
    m.id AS master_id,
    m.name AS master_name,
    COUNT(w.id) AS total_works,
    SUM(CASE WHEN c.is_foreign THEN s.cost_foreign ELSE s.cost_our END) AS total_revenue
FROM masters m
LEFT JOIN works w ON w.master_id = m.id
LEFT JOIN cars c ON w.car_id = c.id
LEFT JOIN services s ON w.service_id = s.id
GROUP BY m.id, m.name
ORDER BY total_revenue DESC NULLS LAST;
-- LEFT JOIN: soldaki tablonun (masters) tüm satırlarını döndürür
--   sağda eşleşme yoksa NULL gelir — hiç işi olmayan ustaları da gösterir
-- COUNT(w.id): NULL saymaz, sadece gerçek işleri sayar
-- SUM(...): ustanın toplam gelirini hesaplar
-- GROUP BY: satırları gruplar, COUNT/SUM her gruba ayrı uygulanır
-- ORDER BY ... DESC: azalan sıralama (en yüksek gelir üstte)
-- NULLS LAST: NULL değerler (işsiz ustalar) listenin sonuna gider

SELECT * FROM v_master_stats;


-- 3.5 Материализованное представление - выручка по услугам
DROP MATERIALIZED VIEW IF EXISTS mv_service_revenue;

CREATE MATERIALIZED VIEW mv_service_revenue AS
SELECT
    s.id AS service_id,
    s.name AS service_name,
    s.cost_our,
    s.cost_foreign,
    COUNT(w.id) AS times_used,
    SUM(CASE WHEN c.is_foreign THEN s.cost_foreign ELSE s.cost_our END) AS total_revenue
FROM services s
LEFT JOIN works w ON w.service_id = s.id
LEFT JOIN cars c ON w.car_id = c.id
GROUP BY s.id, s.name, s.cost_our, s.cost_foreign
ORDER BY total_revenue DESC NULLS LAST;
-- MATERIALIZED VIEW: normal view'dan farklı olarak sonuçları fiziksel olarak diske kaydeder
-- oluşturulurken veya REFRESH edilirken sorgu çalışır, sonrası cache'den okunur
-- avantaj: karmaşık sorguları tekrar tekrar çalıştırmak yerine hazır sonucu okur (hızlı)
-- dezavantaj: veriler eskiyebilir, manuel REFRESH gerekir

-- Обновлять при изменении данных:
-- REFRESH MATERIALIZED VIEW mv_service_revenue;
-- REFRESH: tüm veriyi yeniden hesaplayıp cache'i günceller

SELECT * FROM mv_service_revenue;


-- =============================================
-- 4. INSTEAD OF INSERT триггер на v_works_details
-- =============================================

CREATE OR REPLACE FUNCTION fn_insert_works_details()
RETURNS TRIGGER
LANGUAGE plpgsql AS $$
-- CREATE OR REPLACE FUNCTION: fonksiyon oluşturur ya da varsa üzerine yazar
-- RETURNS TRIGGER: bu fonksiyon trigger ile kullanılmak üzere tasarlandı
-- LANGUAGE plpgsql: PostgreSQL'in prosedürel dili
DECLARE
    v_master_id  INTEGER;
    v_car_id     INTEGER;
    v_service_id INTEGER;
    -- DECLARE: değişken tanımlama bloğu
    -- ara sonuçları saklamak için kullanılır
BEGIN
    SELECT id INTO v_master_id FROM masters WHERE name = NEW.master_name;
    -- NEW: trigger'ın özel değişkeni — INSERT edilen satırın yeni halini tutar
    -- NEW.master_name: INSERT sorgusundaki master_name sütununun değeri
    -- SELECT INTO: sorgu sonucunu değişkene atar
    IF v_master_id IS NULL THEN
        RAISE EXCEPTION 'Мастер "%" не найден', NEW.master_name;
        -- RAISE EXCEPTION: hata fırlatır ve işlemi iptal eder
        -- %: sonraki argümanın değeriyle değiştirilir (placeholder)
    END IF;

    SELECT id INTO v_car_id FROM cars WHERE mark = NEW.car_mark AND num = NEW.car_num;
    IF v_car_id IS NULL THEN
        RAISE EXCEPTION 'Автомобиль "%" №% не найден', NEW.car_mark, NEW.car_num;
    END IF;

    SELECT id INTO v_service_id FROM services WHERE name = NEW.service_name;
    IF v_service_id IS NULL THEN
        RAISE EXCEPTION 'Услуга "%" не найдена', NEW.service_name;
    END IF;

    INSERT INTO works (date_work, master_id, car_id, service_id)
    VALUES (COALESCE(NEW.date_work, CURRENT_DATE), v_master_id, v_car_id, v_service_id);
    -- COALESCE(a, b): ilk NULL olmayan argümanı döndürür
    -- date_work belirtilmezse CURRENT_DATE kullanılır
    -- gerçek works tablosuna usta/araç/hizmet id'leriyle ekleme yapılır

    RETURN NEW;
    -- INSTEAD OF trigger başarıyı bildirmek için NEW döndürmeli
END;
$$;

DROP TRIGGER IF EXISTS trg_insert_works_details ON v_works_details;

CREATE TRIGGER trg_insert_works_details
INSTEAD OF INSERT ON v_works_details
FOR EACH ROW EXECUTE FUNCTION fn_insert_works_details();
-- CREATE TRIGGER: trigger oluşturur
-- INSTEAD OF INSERT: INSERT'in YERINE çalışır (öncesinde ya da sonrasında değil)
--   çok tablolu view'lara doğrudan INSERT yapılamaz, bu trigger sorunu çözer
-- ON v_works_details: hangi nesneye bağlı
-- FOR EACH ROW: eklenen her satır için ayrı ayrı çalışır
-- EXECUTE FUNCTION: trigger fonksiyonunu çağırır

-- Тест вставки через многотабличное представление:
INSERT INTO v_works_details (date_work, master_name, car_mark, car_num, service_name)
VALUES (CURRENT_DATE, 'Иванов Иван', 'Lada Vesta', '3456', 'Замена масла');
-- view'a sanki tablo gibi ekleme yapıyoruz
-- trigger devreye girer, usta/araç/hizmet adlarından id bulur ve works'e yazar

SELECT * FROM v_works_details ORDER BY work_id DESC LIMIT 3;
-- kaydın eklendiğini kontrol ediyoruz


-- =============================================
-- 5. Права на представления для test
-- =============================================

GRANT SELECT ON TABLE v_works_current_year TO test;
GRANT SELECT ON TABLE v_works_details TO test;
GRANT SELECT ON TABLE v_master_stats TO test;
GRANT SELECT ON TABLE mv_service_revenue TO test;
-- view ve materialized view için de GRANT gerekir
-- base tablolara SELECT hakkı olsa bile view'lar için ayrıca verilmeli

GRANT INSERT ON TABLE v_works_details TO test;
-- INSTEAD OF trigger'ı kullanabilmek için INSERT hakkı şart

GRANT USAGE, SELECT ON SEQUENCE works_id_seq TO test;


-- =============================================
-- 6. Роль role_car_manager
-- =============================================

DO $$
BEGIN
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'role_car_manager') THEN
        EXECUTE 'DROP OWNED BY role_car_manager CASCADE';
        EXECUTE 'DROP ROLE role_car_manager';
    END IF;
END
$$;

CREATE ROLE role_car_manager;
-- CREATE ROLE: rol oluşturur (USER'dan farklı olarak varsayılanda LOGIN hakkı yok)
-- rol = birden fazla kullanıcıya toplu hak vermek için kullanılan yetki grubu

GRANT SELECT ON TABLE v_foreign_cars TO role_car_manager;
GRANT UPDATE (color, mark) ON TABLE v_foreign_cars TO role_car_manager;
-- rol yabancı araçları görebilir ve renk + marka sütununu güncelleyebilir
-- sütun seviyesinde UPDATE: sadece listelenen sütunlar

GRANT SELECT ON TABLE v_works_details TO role_car_manager;

GRANT role_car_manager TO test;
-- role TO user: kullanıcı bu rolün tüm haklarını kazanır
-- başka bir kullanıcıya aynı hakları vermek için tek satır yeterli

-- Проверка: \du test
-- \du: psql komutu, kullanıcıların rollerini listeler


-- =============================================
-- 7. Проверка прав (выполнять от имени test)
-- =============================================
-- Подключиться: \c labone test  или новое соединение в VSCode

-- Разрешённые операции:
SELECT * FROM works LIMIT 3;
SELECT * FROM cars LIMIT 3;
SELECT * FROM services LIMIT 3;
SELECT * FROM masters LIMIT 3;
SELECT * FROM v_works_details LIMIT 3;
SELECT * FROM v_master_stats;

INSERT INTO works (date_work, master_id, car_id, service_id)
VALUES (CURRENT_DATE, 1, 1, 1);

UPDATE cars SET color = 'Белый' WHERE id = 1;
-- izin var: GRANT UPDATE (color) verildi

UPDATE v_foreign_cars SET mark = 'Toyota Camry' WHERE id = 1;
-- izin var: role_car_manager rolü UPDATE (color, mark) hakkına sahip

INSERT INTO v_works_details (date_work, master_name, car_mark, car_num, service_name)
VALUES (CURRENT_DATE, 'Иванов Иван', 'Lada Vesta', '3456', 'Замена масла');
-- izin var: GRANT INSERT + INSTEAD OF trigger

-- Запрещённые (должны дать ERROR):
-- UPDATE cars SET num = '9999' WHERE id = 1;
-- HATA: permission denied for table cars
-- açıklama: GRANT UPDATE (color) sadece color sütununu kapsar, num kapsamaz

-- UPDATE services SET cost_our = 0 WHERE id = 1;
-- HATA: permission denied for table services
-- açıklama: sadece SELECT verildi, UPDATE verilmedi

-- DELETE FROM works WHERE id = 1;
-- HATA: permission denied for table works
-- açıklama: GRANT içinde DELETE yoktu


-- =============================================
-- 8. Проверка флагов доступа в psql
-- =============================================
-- \! chcp 1251     - konsol kodlamasını Kiril için değiştir
-- \dp works        - works tablosunun haklarını gösterir
-- \dp cars
-- \dp services
-- \dp              - tüm tablolar için hakları listeler
--
-- \dp çıktısındaki harf anlamları:
-- r = SELECT (read)
-- a = INSERT (append)
-- w = UPDATE (write)
-- d = DELETE
-- D = TRUNCATE
-- x = REFERENCES
-- t = TRIGGER
--
-- Örnek: test=arw/postgres
--   test kullanıcısı INSERT(a) + SELECT(r) + UPDATE(w) haklarına sahip
--   bu hakları postgres süper kullanıcısı verdi
